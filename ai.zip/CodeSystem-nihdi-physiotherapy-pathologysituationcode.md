# CodeSystem NIHDIPhysiotherapyPathology - HL7 Belgium terminology Implementation Guide (IG) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CodeSystem NIHDIPhysiotherapyPathology**

## CodeSystem: CodeSystem NIHDIPhysiotherapyPathology 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://hl7belgium.org/profiles/fhir/terminology//CodeSystem/nihdi-physiotherapy-pathologysituationcode | *Version*:1.0.0 | |
| *Standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:NIHDIPhysiotherapyPathologySituationCode |

 
Legal pathology situation codes as defined by NIHDI to be used in the pathology registration flows of MyCareNet. These values are managed by NIHDI. The codes are not defined here. Consult the cookbooks on mycarenet.be for concrete usage instructions. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [BeProductOrServiceNihdiEAgreement](ValueSet-eagreementproductorservice.md)

This case-sensitive code system `https://hl7belgium.org/profiles/fhir/terminology//CodeSystem/nihdi-physiotherapy-pathologysituationcode` provides **a fragment** that includes following codes:

**Additional Language Displays**



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "nihdi-physiotherapy-pathologysituationcode",
  "extension" : [
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
      "valueCode" : "fhir"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
      "valueInteger" : 1,
      "_valueInteger" : {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
            "valueCanonical" : "https://www.ehealth.fgov.be/standards/fhir/mycarenet/ImplementationGuide/hl7.fhir.be.mycarenet"
          }
        ]
      }
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
      "valueCode" : "trial-use",
      "_valueCode" : {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
            "valueCanonical" : "https://www.ehealth.fgov.be/standards/fhir/mycarenet/ImplementationGuide/hl7.fhir.be.mycarenet"
          }
        ]
      }
    }
  ],
  "url" : "https://hl7belgium.org/profiles/fhir/terminology//CodeSystem/nihdi-physiotherapy-pathologysituationcode",
  "version" : "1.0.0",
  "name" : "NIHDIPhysiotherapyPathologySituationCode",
  "title" : "CodeSystem NIHDIPhysiotherapyPathology",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-02-17T19:47:43+01:00",
  "publisher" : "My Organization",
  "contact" : [
    {
      "name" : "My Organization",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://example.com/committees"
        },
        {
          "system" : "email",
          "value" : "my-group@example.com"
        }
      ]
    },
    {
      "name" : "Bob Smith",
      "telecom" : [
        {
          "system" : "email",
          "value" : "bobsmith@example.com",
          "use" : "work"
        }
      ]
    }
  ],
  "description" : "Legal pathology situation codes as defined by NIHDI to be used in the pathology registration flows of MyCareNet. These values are managed by NIHDI. The codes are not defined here. Consult the cookbooks on mycarenet.be for concrete usage instructions.",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
          "code" : "001",
          "display" : "World"
        }
      ]
    }
  ],
  "caseSensitive" : true,
  "content" : "fragment",
  "concept" : [
    {
      "code" : "fa-1",
      "display" : "fa-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "a) Volgende posttraumatische of postoperatieve aandoeningen:situaties waarin één of meerdere verstrekkingen uit artikel 14 k) (orthopedie), I (heelkundige verstrekkingen) en III\r\n(diagnostische en therapeutische arthroscopieën) zijn aangerekend en waarin de verstrekking of de som van die\r\nverstrekkingen overeenkomst met een waarde van N 200 of meer;"
        },
        {
          "language" : "fr-BE",
          "value" : "a) Affections posttraumatiques ou postopératoires:situations dans lesquelles une ou plusieurs prestations de l'article 14, k) (orthopédie), I (prestations chirurgicales) et III (arthroscopies diagnostiques et thérapeutiques), sont attestées et pour lesquelles la prestation ou la somme de ces\r\nprestations correspond à une valeur de N200 ou plus;"
        }
      ]
    },
    {
      "code" : "fa-2",
      "display" : "fa-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "a) Volgende posttraumatische of postoperatieve aandoeningen:situaties waarin een verstrekking uit artikel 14 b) (neurochirurgie) zijn aangerekend en waarin deze verstrekking\r\novereenkomt met een waarde van K 225 of meer;"
        },
        {
          "language" : "fr-BE",
          "value" : "a) Affections posttraumatiques ou postopératoires:situations dans lesquelles une prestation de l'article 14, b) (neurochirurgie) est attestée et pour laquelle la prestation correspond à une valeur de K225 ou plus"
        }
      ]
    },
    {
      "code" : "fa-2-b",
      "display" : "fa-2-b",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "a) Volgende posttraumatische of postoperatieve aandoeningen:in geval van handletsels, situaties waarin één of meerdere verstrekkingen uit artikel 14, k) (orthopedie) I\r\n(heelkundige verstrekkingen) met een totale waarde van Nx en een verstrekking van artikel 14, b) (neurochirurgie)\r\nmet een waarde van Ky tegelijk zijn verricht terwijl het resultaat van de volgende berekening [Nx/N200 +\r\nKy/K225] hoger is dan of gelijk is aan 1;"
        },
        {
          "language" : "fr-BE",
          "value" : "a) Affections posttraumatiques ou postopératoires:en cas de lésions de la main, situations dans lesquelles une ou plusieurs prestations de l’article 14, k) (orthopédie) I (prestations chirurgicales) d’une valeur totale de Nx et une prestation de l’article 14, b) (neurochirurgie) d’une valeur de Ky  sont effectuées conjointement lorsque le résultat du calcul suivant [Nx/N200 + Ky/225] est supérieur ou égal à 1 ;"
        }
      ]
    },
    {
      "code" : "fa-3",
      "display" : "fa-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "a) Volgende posttraumatische of postoperatieve aandoeningen:situaties waarbij een van de verstrekkingen 227695-227706, 227710-227721, 227813-227824, 227835-227846,\r\n226936-226940, 227592-227603, 227614-227625, 227651-227662, 227673-227684, 227776-2277801 of 227791-\r\n227802 is geattesteerd uit artikel 14, e) van de nomenclatuur."
        },
        {
          "language" : "fr-BE",
          "value" : "a) Affections posttraumatiques ou postopératoires:situations dans lesquelles une des prestations 227695–227706, 227710–227721, 227813-227824, 227835– 227846, 226936-226940, 227592–227603, 227614–227625, 227651-227662, 227673-227684, 227776-227780 ou 227791-\r\n227802 de l'article 14, e) de la nomenclature est attestée."
        }
      ]
    },
    {
      "code" : "fa-4",
      "display" : "fa-4",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "b) Situaties waarbij de verstrekkingen 211046, 212225 of 214045, (artikel 13, § 1 van de nomenclatuur (reanimatie)) werden\r\naangerekend."
        },
        {
          "language" : "fr-BE",
          "value" : "b) Situations dans lesquelles les prestations 211046, 212225 ou 214045 (article 13, § 1er de la nomenclature (réanimation)) a été attestée"
        }
      ]
    },
    {
      "code" : "fa-5",
      "display" : "fa-5",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "c) Situaties waarbij de rechthebbenden opgenomen zijn geweest in een erkende functie intensieve verzorging (code 490), in\r\neen erkende functie plaatselijke neonatale verzorging (functie N*\r\n) (code 190) of in een erkende dienst voor intensieve\r\nneonatalogie (NIC) (code 270)."
        },
        {
          "language" : "fr-BE",
          "value" : "c) Bénéficiaires après une admission en fonction de soins intensifs (code 490), dans une fonction de soins néonatals locaux (fonction N°) (code 190) ou un service de néonatalgie intensive (NIC) (code 270)"
        }
      ]
    },
    {
      "code" : "fa-6",
      "display" : "fa-6",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "d) Ademhalingsinsufficiëntie bij kinderen onder 16 jaar met tracheo-, laryngo- of bronchomalacie of recidiverende lage\r\nluchtwegeninfecties"
        },
        {
          "language" : "fr-BE",
          "value" : "c) Insuffisance respiratoire pour les enfants de moins de 16 ans souffrant de trachéo-, laryngo- ou bronchomalacie ou d'infections récidivantes des voies respiratoires inférieures."
        }
      ]
    },
    {
      "code" : "fa-7",
      "display" : "fa-7",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "e) Motorisch deficit en invalidering als gevolg van:mononeuropathie (bijvoorbeeld dropvoet, drophand);"
        },
        {
          "language" : "fr-BE",
          "value" : "e) Déficit moteur et invalidité à la suited'une mononeuropathie (par exemple pied tombant ou main tombante);"
        }
      ]
    },
    {
      "code" : "fa-8",
      "display" : "fa-8",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "e) Motorisch deficit en invalidering als gevolg van:motorische of gemengde polyneuropathie;"
        },
        {
          "language" : "fr-BE",
          "value" : "e) Déficit moteur et invalidité à la suited'une polyneuropathie motrice ou mixte;"
        }
      ]
    },
    {
      "code" : "fa-9",
      "display" : "fa-9",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "e) Motorisch deficit en invalidering als gevolg van:myopathie geïnduceerd door medicatie of door acuut of chronisch contact met toxische stoffen."
        },
        {
          "language" : "fr-BE",
          "value" : "e) Déficit moteur et invalidité à la suited'une myopathie induite par médication ou par contact aigu ou chronique avec des substances toxiques."
        }
      ]
    },
    {
      "code" : "fa-10",
      "display" : "fa-10",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "f) Situaties in het domein van de orthopedie – traumatologie 10.\r\n - wervelbreuk die gedurende minstens drie weken met een gipsverband, een korset of een orthese werd\r\ngeïmmobiliseerd;\r\n\r\n - bekkenbreuk die gedurende minstens drie weken een immobilisatie of partieel of volledig steunverbod\r\nvereist;\r\n\r\n - breuken aan de knieschijf, het tibiaplateau, de humeruskop, de elleboog of intra-articulaire breuken ter\r\nhoogte van de ledematen, die gedurende minstens drie weken werd geïmmobiliseerd;\r\n\r\n - luxatie van de elleboog, de heup, de heupprothese, het schoudergewricht of de schouderprothese;\r\n - ernstige knievertuikingen met gehele of partiële ruptuur van één of meerdere ligamenten."
        },
        {
          "language" : "fr-BE",
          "value" : "f) Situations dans le domaine de l'orthopédie – traumatologie \r\n - fracture vertébrale qui a nécessité une immobilisation par plâtre, corset ou orthèse d'au moins trois semaines;\r\n - fracture du bassin qui nécessite une immobilisation ou une décharge totale ou partielle d'au moins trois semaines;\r\n - fracture de la rotule, du plateau tibial, de la tête humérale, du coude ou fracture intra-articulaire à la hauteur des\r\n membres, qui ont nécessité une immobilisation d'au moins trois semaines;\r\n - luxation du coude, de la hanche, de la prothèse de hanche ou de l'articulation de l'épaule ou de la prothèse de\r\nl'épaule;\r\n - entorse grave du genou avec rupture totale ou partielle d'un ou de plusieurs ligaments."
        }
      ]
    },
    {
      "code" : "fa-11",
      "display" : "fa-11",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "g) Adhesieve capsulitis (frozen shoulder)"
        },
        {
          "language" : "fr-BE",
          "value" : "g) Capsulite rétractile (frozen shoulder)"
        }
      ]
    },
    {
      "code" : "fa-12",
      "display" : "fa-12",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "h) Situaties die uro-, gynaeco-, colo- of proctologische revalidatie vereisenbewezen neuropathie, zowel bij mannen als bij vrouwen"
        },
        {
          "language" : "fr-BE",
          "value" : "h) Situations nécessitant une rééducation uro-, gynéco-, colo- ou proctologiqueNeuropathie avérée, tant chez les femmes que chez les hommes"
        }
      ]
    },
    {
      "code" : "fa-13",
      "display" : "fa-13",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "h) Situaties die uro-, gynaeco-, colo- of proctologische revalidatie vereisenpostoperatieve revalidatie van sfyncterdisfunctie na: 13. (01) radicale prostatectomie of adenomectie. (02) totale cystectomie met vervangblaas ingeplant op de urethra bij patiënten die lijden aan urinaire incontinentie en/of verminderd aandranggevoel (03) verwijdering van een deel van het spijsverteringskanaal met behoud van de anale sfyncter. (04) fverzakking van blaas, rectum of baarmoeder na een chirurgische ingreep."
        },
        {
          "language" : "fr-BE",
          "value" : "h) Situations nécessitant une rééducation uro-, gynéco-, colo- ou proctologiqueRééducation postopératoire du dysfonctionnement sphinctérien après:\r\n(01) Prostatectomie radicale ou adénomectomie\r\n(02) Cystectomie totale avec entéro-cystoplastie chez des patients présentant une incontinence urinaire et/ou un déficit de sensibilité de réplétion vésicale.\r\n(03) Amputation d'une partie du système digestif avec maintien du sphincter anal\r\n(04) Prolapsus vésical, rectal ou utérin après intervention chirurgicale."
        }
      ]
    },
    {
      "code" : "fa-14",
      "display" : "fa-14",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "h) Situaties die uro-, gynaeco-, colo- of proctologische revalidatie vereisenfunctionele aandoeningen bij kinderen tot de 16e\r\n varjaardag ten gevolge van één van de volgende disfuncties of\r\nmisvormingen\r\n(01) urinaire aandoeningen die op korte en middellange termijn een bedreiging vormen voor de\r\nhogere urinewegen:\r\n\r\n - dyssynergie tussen blaas en sfincter\r\n - recidiverende urinewegeninfecties\r\n - postoperatief syndroom van urethrakleppen\r\n - vesicale immaturiteit\r\n (02) encopresis bij het kind"
        },
        {
          "language" : "fr-BE",
          "value" : "h) Situations nécessitant une rééducation uro-, gynéco-, colo- ou proctologiquePathologies fonctionnelles pour les enfants jusqu'au 16ème anniversaire dues à des dysfonctionnements 14.\r\n ou des malformations:\r\n(1) infections urinaires pouvant constituer une menace pour le haut appareil urinaire à court et moyen termes:\r\n - dyssynergie vésico-sphinctérienne\r\n - infections urinaires à répétition\r\n - syndrome des valves urétrales post-opératoire\r\n - immaturité vésicale\r\n (2) encoprésie chez l’enfant"
        }
      ]
    },
    {
      "code" : "fa-15",
      "display" : "fa-15",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "i) Reflex Sympathische dystrofie (RSD) van het type I (algoneurodystrofie of Südeckatrofie) of van het type II (causalgie)"
        },
        {
          "language" : "fr-BE",
          "value" : "i) Syndrome Douloureux Régional Complexe (SDRC) de type I (algoneurodystrophie ou maladie de Südeck)  ou de type II (causalgie)"
        }
      ]
    },
    {
      "code" : "fa-16",
      "display" : "fa-16",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "j) Polytraumatismen, met invaliderende functionele gevolgen ter hoogte van twee verschillende ledematen of ter hoogte van\r\neen lidmaat en de romp, waarvan ten minste 2 traumatismen voldoen aan de criteria van de pathologische situaties\r\nomschreven in § 14, 5°, A, a), 1) of 2) (posttraumatische of postoperatieve aandoeningen) en/of in § 14, 5°, A, f) (situaties\r\nin het domein van de orthopedie – traumatologie)"
        },
        {
          "language" : "fr-BE",
          "value" : "j) Polytraumatismes, avec des répercussions fonctionnelles invalidantes au niveau de deux membre différents ou au niveau\r\nd’un membre et du tronc, dont au moins 2 traumatismes répondent aux critères des situations pathologiques définies au § 14,\r\n5°, A, a),\r\n1) ou 2) (affections posttraumatiques ou postopératoires) et/ou au § 14, 5°, A, f) (situations dans le domaine de\r\nl’orthopédie - traumatologie)"
        }
      ]
    },
    {
      "code" : "fa-17",
      "display" : "fa-17",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "k) De volgende situaties in het domein van de stomatologie: \r\n- na een intra-articulaire temporomandibulaire heelkundige ingreep;\r\n - tijdens en/of na radiotherapie betreffende de maxillo-faciale zone;\r\n - na een intra-articulaire of sub-condylaire mandibulaire breuk;"
        },
        {
          "language" : "fr-BE",
          "value" : "k) Situations dans le domaine de la stomatologie énumérées ci-dessous :\r\n - après une intervention chirurgicale temporomandibulaire intra-articulaire;\r\n - pendant et/ou après une radiothérapie concernant la région maxillo-faciale\r\n - après une fracture mandibulaire intra-articulaire ou sub-condylaire"
        }
      ]
    },
    {
      "code" : "fb-51",
      "display" : "fb-51",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "a) Situaties die een gangrevalidatie noodzakelijk maken voor rechthebbenden vanaf hun 65ste\r\nverjaardag, die al eens gevallen zijn met het risico op herhaling, te objectiveren door de behandelend\r\ngeneesheer en kinesitherapeut aan de hand van:\r\n1) de “Timed up & go” test, met een score hoger dan 20 seconden;\r\nen\r\n2) een positief resultaat op ten minste één van twee volgende testen, die allebei moeten worden verricht:\r\n(01) de “Tinetti” test, met een score kleiner dan 20/28;\r\n(02) de “Timed chair stands” test, met een score hoger dan 14 seconden."
        },
        {
          "language" : "fr-BE",
          "value" : "a) Situations qui nécessitent une rééducation fonctionnelle de la marche pour les bénéficiaires à partir de leur 65ème anniversaire ayant déjà été victime d’une chute et présentant un risque de récidive, à objectiver par le médecin traitant et le kinésithérapeute\r\nau moyen :\r\n1) du test « Timed up & go », avec un score supérieur à 20 secondes;\r\net\r\n2) du résultat positif à au moins un des deux tests suivants, ceux-ci devant tous deux être effectués :\r\n(01) – le test « Tinetti », avec un score inférieur à 20/28;\r\n(02) – le test « Timed chair stands », avec un score supérieur à 14 secondes"
        }
      ]
    },
    {
      "code" : "fb-59",
      "display" : "fb-59",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "b) Psychomotorische ontwikkelingsstoornissen\r\nBij kinderen onder 16 jaar, na advies en behandelingsvoorstel door een van ondervermelde\r\ngeneesheren-specialisten en met een significant zwakkere score op een gestandaardiseerde test;\r\nGeneesheer-specialist voor:\r\n- (neuro)pediatrie\r\n- (neuro)pediatrie en F en P (*)\r\n- neuropsychiatrie en F en P (*)\r\n- neurologie\r\n- neurologie en F en P (*)\r\n- psychiatrie\r\n- psychiatrie en F en P (*)\r\n(*) F en P = specialist voor functionele en professionele revalidatie voor gehandicapten\r\nBij kinderen onder 19 maanden kan bovenvermeld advies, behandelingsvoorstel en significant\r\nzwakkere score vervangen worden door de vaststelling van klinisch duidelijke\r\nontwikkelingsstoornissen op basis van een evaluatie in een gespecialiseerde multidisciplinaire\r\nequipe, waar ten minste een (neuro)pediater deel van uitmaakt."
        },
        {
          "language" : "fr-BE",
          "value" : "b) Troubles du développement psychomoteur\r\nChez les enfants de moins de 16 ans, après avis et proposition de traitement d’un des médecins spécialistes mentionnés\r\nci-dessous, et avec un score significativement plus faible sur un test standardisé ;\r\nMédecin spécialiste en :\r\n- (neuro)pédiatrie\r\n- (neuro)pédiatrie et F et P (*)\r\n- neuropsychiatrie et F et P (*)\r\n- neurologie\r\n- neurologie et F et P (*)\r\n- psychiatrie\r\n- psychiatrie et F et P (*)\r\n\r\n(*) F et P = spécialiste en réadaptation fonctionnelle et professionnelle des handicapés\r\nChez les enfants de moins de 19 mois, l’avis, la proposition de traitement et le score significativement plus faible mentionnés\r\nci-dessus peuvent être remplacés par la constatation de troubles manifestes clinique du développement sur base d’une\r\névaluation effectuée par une équipe multidisciplinaire spécialisée, qui compte au moins un (neuro)pédiatre"
        }
      ]
    },
    {
      "code" : "fb-54",
      "display" : "fb-54",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "c) Ademhalingsinsufficiëntie bij rechthebbenden die opgevolgd worden in het kader van de\r\ntyperevalidatie-overeenkomst inzake langdurige zuurstoftherapie thuis of bij thuisbeademing."
        },
        {
          "language" : "fr-BE",
          "value" : "c) Insuffisance respiratoire chez les bénéficiaires qui sont suivis dans le cadre de la convention-type de rééducation fonctionnelle relative à l'oxygénothérapie de longue durée à domicile ou en cas de respiration artificielle à domicile."
        }
      ]
    },
    {
      "code" : "fb-55",
      "display" : "fb-55",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "d) Chronische motorische of gemengde polyneuropathie."
        },
        {
          "language" : "fr-BE",
          "value" : "d) Polyneuropathie chronique motrice ou mixte."
        }
      ]
    },
    {
      "code" : "fb-56",
      "display" : "fb-56",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "e) Chronisch vermoeidheidssyndroom\r\ndie voldoen aan de voorwaarden beschreven in de nomenclatuur"
        },
        {
          "language" : "fr-BE",
          "value" : "e) Syndrome de fatigue chronique répondant aux conditions prévues dans la nomenclature."
        }
      ]
    },
    {
      "code" : "fb-57",
      "display" : "fb-57",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "f) Fibromyalgiesyndroom\r\nDe diagnose moet bevestigd zijn door een geneesheer, specialist voor reumatologie of in de\r\nfysische geneeskunde en de revalidatie, op grond van een klinisch onderzoek dat de\r\ndiagnostische criteria van de ACR (American College of Rheumatology) omvat. Deze\r\nbevestiging, getekend door de geneesheer-specialist, moet voorkomen in het individueel\r\nkinesitherapiedossier en weergeven dat de gebruikte diagnostische criteria wel degelijk die van\r\nde ACR zijn.\r\nVoor het einde van elk kalenderjaar dat volgt op het jaar van de eerste verstrekking van de\r\nbehandeling, moet de voornoemde geneesheer-specialist de evolutie van de symptomen\r\nopnieuw evalueren, teneinde te bevestigen dat het noodzakelijk is dat de behandeling wordt\r\nvoortgezet in het kader van §14. Deze bevestiging, getekend door de geneesheer-specialist,\r\nmoet voorkomen in het individueel kinesitherapiedossier."
        },
        {
          "language" : "fr-BE",
          "value" : "f) Syndrome fibromyalgique \r\nLe diagnostic doit être confirmé par un médecin spécialiste en rhumatologie ou en médecine physique et réadaptation sur base\r\nd’un examen clinique comprenant les critères de diagnostic de l’ACR (American College of Rheumatology). Cette confirmation\r\nsignée par le médecin spécialiste doit figurer dans le dossier individuel kinésithérapeutique et préciser que les critères de\r\ndiagnotic utilisés sont bien ceux de l’ACR\r\nAvant la fin de chaque année civile qui suit l’année au cours de laquelle la 1ère prestation du traitement a eu lieu, le médecin\r\nspécialiste susmentionné réévaluera l’évolution de la symptomatologie du patient afin de confirmer la nécessité de poursuivre le\r\ntraitement dans le cadre du § 14. Cette confirmation signée par le médecin spécialiste doit figurer dans le dossier individuel\r\nkinésithérapeutique"
        }
      ]
    },
    {
      "code" : "fb-58",
      "display" : "fb-58",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "g) Primaire cervicale dystonie\r\naangetoond met een diagnostische verslag opgesteld door een geneesheer-specialist voor\r\nneurologie"
        },
        {
          "language" : "fr-BE",
          "value" : "g) Dystonie cervicale primaire démontrée par un rapport diagnostique établi par un médecin-spécialiste en neurologie"
        }
      ]
    },
    {
      "code" : "fb-60",
      "display" : "fb-60",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "h) Lymfoedeem\r\ndie voldoen aan de voorwaarden beschreven in de nomenclatuur"
        },
        {
          "language" : "fr-BE",
          "value" : "h) lymphoedème \r\nrépondant aux conditions prévues dans la nomenclature"
        }
      ]
    },
    {
      "code" : "e-na",
      "display" : "e-na",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onbepaalde pathologische situatie (oud papier akkoord)"
        },
        {
          "language" : "fr-BE",
          "value" : "Situation pathologique non définie (ancien accord papier)"
        }
      ]
    },
    {
      "code" : "e-a",
      "display" : "e-a",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "a) Uitgebreide perifere verlamming: monoplegie, syndroom van Guillain Barré;"
        },
        {
          "language" : "fr-BE",
          "value" : "a) Paralysie périphérique étendue : monoplégie, syndrome de Guillain Barré."
        }
      ]
    },
    {
      "code" : "e-b",
      "display" : "e-b",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "b) Evolutieve aandoeningen van het centrale zenuwstelsel met een uitgebreid motorisch gebrek zoals bij voorbeeld multiple sclerose, de ziekte van Parkinson en de amyotrofische laterale sclerose…;"
        },
        {
          "language" : "fr-BE",
          "value" : "b) Affections neurologiques centrales de caractère évolutif avec déficit moteur étendu.\r\nExemples : sclérose en plaques, maladie de Parkinson, sclérose latérale amyotrophique, etc."
        }
      ]
    },
    {
      "code" : "e-c",
      "display" : "e-c",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "c) Uitbegreide motorische sequellen van encefale of medullaire oorsprong (bijvoorbeeld: hersenverlamming “Cerebral Palsy”, hemiplegie, spina bifida, cerebellair syndroom,…);"
        },
        {
          "language" : "fr-BE",
          "value" : "c) Séquelles motrices étendues d'origine encéphalique ou médullaire.\r\nExemples : infirmité motrice cérébrale \"Cerebral Palsy\", hémiplégie, spina bifida, syndrome cérébelleux, etc."
        }
      ]
    },
    {
      "code" : "e-d",
      "display" : "e-d",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "d) Sequellen van zware brandwonden ter hoogte van de ledematen en/of de hals tijdens de evolutieve fase;"
        },
        {
          "language" : "fr-BE",
          "value" : "d) Suites de brûlures graves au niveau des membres et/ou du cou pendant la phase évolutive."
        }
      ]
    },
    {
      "code" : "e-e-1",
      "display" : "e-e-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "e) functioneel verliesbelangrijk functioneel verlies van een lidmaat ten gevolge van een agenesie van een lidmaat of van een dysmelie die de anatomie van zijn verschillende segmenten aantast"
        },
        {
          "language" : "fr-BE",
          "value" : "e) Perte fonctionnelle :Perte fonctionnelle importante d’un membre suite à une agénésie du membre ou à une dysmélie affectant l’anatomie de ses différents segments"
        }
      ]
    },
    {
      "code" : "e-e-2",
      "display" : "e-e-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "e) functioneel verliesglobaal functioneel verlies van een lidmaat door amputatie, tijdens de aanpassingsperiode;"
        },
        {
          "language" : "fr-BE",
          "value" : "e) Perte fonctionnelle :Perte fonctionnelle globale d'un membre suite à une amputation, pendant la période d'adaptation"
        }
      ]
    },
    {
      "code" : "e-e-3",
      "display" : "e-e-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "e) functioneel verliesGlobaal posttraumatische functioneel verlies van een lidmaat, tijdens de evolutieve periode;"
        },
        {
          "language" : "fr-BE",
          "value" : "e) Perte fonctionnelle :Perte fonctionnelle globale post-traumatique d'un membre, pendant la période évolutive"
        }
      ]
    },
    {
      "code" : "e-f",
      "display" : "e-f",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "f) Spits- en klompvoet, bij een kind jonger dan 2 jaar;"
        },
        {
          "language" : "fr-BE",
          "value" : "f) Pied bot varus équin chez l'enfant de moins de 2 ans."
        }
      ]
    },
    {
      "code" : "e-g-1",
      "display" : "e-g-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "g) Ernstige gewrichtsdysfunctie ten gevolge van:hemofilie;"
        },
        {
          "language" : "fr-BE",
          "value" : "g) Dysfonction articulaire grave résultant :d’une hémophilie"
        }
      ]
    },
    {
      "code" : "e-g-2",
      "display" : "e-g-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "g) Ernstige gewrichtsdysfunctie ten gevolge van:erfelijke bindweefselaandoeningen (osteogenesis imperfecta van het type III en IV, Ehlers-Danlos-syndroom, chondrodysplasieën, Marfan-syndroom);"
        },
        {
          "language" : "fr-BE",
          "value" : "g) Dysfonction articulaire grave résultant :de maladies héréditaires du tissu conjonctif (ostéogenèse imparfaite de type III et IV, syndrome d'Ehlers-Danlos, chondrodysplasies, syndrome de Marfan)"
        }
      ]
    },
    {
      "code" : "e-g-3",
      "display" : "e-g-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "g) Ernstige gewrichtsdysfunctie ten gevolge van:evolutieve scoliose met een kromming van minstens 15° (of hoek van Cobb) bij rechthebbenden onder de 18 jaar;"
        },
        {
          "language" : "fr-BE",
          "value" : "g) Dysfonction articulaire grave résultant :d’une scoliose évolutive de 15° au moins d'angle de courbure (ou angle de Cobb) chez des bénéficiaires en dessous de 18 ans"
        }
      ]
    },
    {
      "code" : "e-g-4",
      "display" : "e-g-4",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "g) Ernstige gewrichtsdysfunctie ten gevolge van: arthrogrypose;"
        },
        {
          "language" : "fr-BE",
          "value" : "g) Dysfonction articulaire grave résultant :d’une arthrogrypose"
        }
      ]
    },
    {
      "code" : "e-h-1",
      "display" : "e-h-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "h) Chronische auto-immune inflammatoire polyarthritis:Reumatoïde artritis"
        },
        {
          "language" : "fr-BE",
          "value" : "h) Polyarthrites chroniques inflammatoires d’origine immunitaire :Arthrite rhumatoïde"
        }
      ]
    },
    {
      "code" : "e-h-2",
      "display" : "e-h-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "h) Chronische auto-immune inflammatoire polyarthritis:Spondyloarthropathie"
        },
        {
          "language" : "fr-BE",
          "value" : "h) Polyarthrites chroniques inflammatoires d’origine immunitaire :Spondyloarthropathies"
        }
      ]
    },
    {
      "code" : "e-h-3",
      "display" : "e-h-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "h) Chronische auto-immune inflammatoire polyarthritis:Juveniele chronische artritis"
        },
        {
          "language" : "fr-BE",
          "value" : "h) Polyarthrites chroniques inflammatoires d’origine immunitaire :Arthrite rhumatoïde juvénile"
        }
      ]
    },
    {
      "code" : "e-h-4",
      "display" : "e-h-4",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "h) Chronische auto-immune inflammatoire polyarthritis:  Systemische lupus"
        },
        {
          "language" : "fr-BE",
          "value" : "h) Polyarthrites chroniques inflammatoires d’origine immunitaire :Lupus erythémateux"
        }
      ]
    },
    {
      "code" : "e-h-5",
      "display" : "e-h-5",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "h) Chronische auto-immune inflammatoire polyarthritis: Sclerodermie"
        },
        {
          "language" : "fr-BE",
          "value" : "h) Polyarthrites chroniques inflammatoires d’origine immunitaire :Sclérodermie"
        }
      ]
    },
    {
      "code" : "e-h-6",
      "display" : "e-h-6",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "h) Chronische auto-immune inflammatoire polyarthritis:Primair syndroom van Sjögren, volgens de definities aanvaard door de Koninklijke Belgische      Vereniging voor Reumatologie"
        },
        {
          "language" : "fr-BE",
          "value" : "h) Polyarthrites chroniques inflammatoires d’origine immunitaire :Syndrome de Sjögren primaire (selon les définitions acceptées par la Société Royale Belge de Rhumatologie)"
        }
      ]
    },
    {
      "code" : "e-i-1",
      "display" : "e-i-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "i) Myopathieën:    de progressieve erfelijke musculaire dystrofieën;"
        },
        {
          "language" : "fr-BE",
          "value" : "i) Myopathies :Dystrophies musculaires progressives héréditaires"
        }
      ]
    },
    {
      "code" : "e-i-2",
      "display" : "e-i-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "i) Myopathieën:     de myotonia congenita van Thomsen;"
        },
        {
          "language" : "fr-BE",
          "value" : "i) Myopathies :Myotonie congénitale de Thomsen"
        }
      ]
    },
    {
      "code" : "e-i-3",
      "display" : "e-i-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "i) Myopathieën:     de auto-immune polymuosotis;"
        },
        {
          "language" : "fr-BE",
          "value" : "i) Myopathies :Polymyosite auto-immune"
        }
      ]
    },
    {
      "code" : "e-j-1",
      "display" : "e-j-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "j) longaandoeningen:Mucoviscidose of geobjectiveerde primaire bronchiale ciliaire dyskinesie;"
        },
        {
          "language" : "fr-BE",
          "value" : "j) Affections pulmonaires :Mucoviscidose ou dyskinésie ciliaire bronchiale primaire objectivées"
        }
      ]
    },
    {
      "code" : "e-j-2",
      "display" : "e-j-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "j) longaandoeningen:Geobjectiveerde hyperproductieve bronchiectasieën"
        },
        {
          "language" : "fr-BE",
          "value" : "j) Affections pulmonaires :Bronchiectasies hyperproductives objectivées"
        }
      ]
    },
    {
      "code" : "e-j-3",
      "display" : "e-j-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "j) longaandoeningen:Irreversibele chronische obstructieve of restrictieve longaandoeningen met maximum expiratoire seconde         capaciteit waarden van minder dan of gelijk aan 60%,   opgemeten in een tussenperiode van minstend één maand;  bij een kind jonger dan 7 jaar kan de irreversibele ademhalingsinsufficiëntie worden vastgesteld op basis van   een gemotiveerd verslag van de behandelende arts;"
        },
        {
          "language" : "fr-BE",
          "value" : "j) Affections pulmonaires :Affections pulmonaires chroniques irréversibles obstructives ou restrictives avec des valeurs de volume expiratoire maximum-seconde inférieures ou égales à 60 % mesurées à un intervalle d'au moins 1 mois. Chez un enfant de moins de 7 ans, l'insuffisance respiratoire irréversible pourra être établie sur base d'un rapport motivé du spécialiste traitant"
        }
      ]
    },
    {
      "code" : "e-j-4",
      "display" : "e-j-4",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "j) longaandoeningen:Recidiverende pulmonaire infecties bij bewezen ernstige immunodepressie;"
        },
        {
          "language" : "fr-BE",
          "value" : "j) Affections pulmonaires :Infections pulmonaires récidivantes en cas d'immunodépression grave établie"
        }
      ]
    },
    {
      "code" : "e-j-5",
      "display" : "e-j-5",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "j) longaandoeningen:    Broncho-pulmonaire dysplasie met zuurstofafhankelijkheid    gedurende meer dan 28 dagen. De met redenen omklede aanvraag van de behandelende kinderarts moet met name het verslag over de opneming in een dienst N omvatten;"
        },
        {
          "language" : "fr-BE",
          "value" : "j) Affections pulmonaires :Dysplasie broncho-pulmonaire avec oxygénodépendance de plus de 28 jours. La demande motivée du pédiatre traitant comportera notamment le rapport d'hospitalisation en service N."
        }
      ]
    },
    {
      "code" : "e-k",
      "display" : "e-k",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "k) Lymfoedeem: \r\n\r\nBij een eenzijdige aantasting ter hoogte van een lidmaat (bovenste of onderste) door een postradiotherapeutisch of postchirurgisch lymfoedeem dat beantwoordt aan de volgende criteria:\r\nofwel moet een perimetrie die is uitgevoerd op het hele lidmaat, of een volumetrisch onderzoek van de hand of de voet een verschil van +10 % aantonen ten opzichte van het contralaterale lidmaat. Die metingen moeten worden uitgevoerd volgens de protocollen die zijn vastgelegd door het Verzekeringscomité, op voorstel van het College van geneesheren-directeurs\r\nofwel moet een lymfoscintigrafisch onderzoek in 3 stappen de ernst van de diagnose bevestigen als aan een belangrijk criterium is voldaan volgens de lymfoscintigrafische classificatie van de oedemen van de ledematen met het oog op de kinesitherapeutische tenlasteneming ervan. Die classificatie wordt vastgelegd door het Verzekeringscomité, op voorstel van het College van geneesheren-directeurs\r\nVoor alle andere soorten van lymfoedeem moet een lymfoscintigrafisch onderzoek in 3 stappen de diagnose bevestigen als aan een belangrijk criterium is voldaan volgens de lymfoscintigrafische classificatie van de oedemen met het oog op de kinesitherapeutische tenlasteneming ervan.\r\n\r\nNochtans is een lymfoscintigrafisch onderzoek niet vereist in 3 gevallen:\r\nals het een cervico-faciaal oedeem betreft:\r\nals het een patiënt jonger dan 14 jaar betreft waarvoor het uitvoeren van een lymfoscintigrafisch onderzoek in drie stappen niet aangewezen is\r\nin geval van gemotiveerde fysieke onmogelijkheid om een lymfoscintigrafisch onderzoek in drie stappen uit te voeren.\r\nIn die 3 gevallen moet de geneesheer-specialist een gemotiveerd verslag dat de diagnose en de verzorgingsnood rechtvaardigt, aan de adviserend-geneesheer bezorgen. Deze zal, indien hij dat nuttig acht, dat dossier voor advies aan het College van Geneesheren-directeurs bezorgen."
        },
        {
          "language" : "fr-BE",
          "value" : "k) Lymphoedème :\r\nEn cas d’atteinte unilatérale au niveau d’un membre (supérieur ou inférieur) pour un lymphoedème post-radiothérapeutique ou post-chirurgical répondant aux critères suivants :\r\nsoit une périmétrie effectuée sur l’ensemble du membre ou une volumétrie de la main ou du pied montre une différence par rapport au membre controlatéral de +10 %. Ces mesures doivent être effectuées selon les protocoles fixés par le Comité de l’assurance soins de santé, sur proposition du Collège des médecins-directeurs\r\nsoit une lymphoscintigraphie en 3 temps atteste de la gravité du diagnostic avec présence d’un critère majeur selon la classification lymphoscintigraphique des œdèmes des membres visant à leur prise en charge kinésithérapeutique. Cette classification est fixée par le Comité de l’assurance soins de santé, sur proposition du Collège des médecins-directeurs\r\nPour tous les autres types de lymphoedème, une lymphoscintigraphie en trois temps doit attester du diagnostic avec présence d’un critère majeur selon la classification lymphoscintigraphique des œdèmes visant à leur prise en charge kinésithérapeutique.\r\n\r\nNéanmoins, une lymphoscintigraphie n’est pas exigée dans 3 cas :\r\nil s’agit d’un lymphoedème cervico-facial\r\nil s’agit d’un patient de moins de 14 ans pour lequel la réalisation d’une lymphoscintigraphie en 3 temps n’est pas indiquée\r\nimpossibilité physique motivée de réaliser une lymphoscintigraphie en 3 temps.\r\nDans ces 3 cas, le médecin spécialiste doit envoyer au médecin-conseil un rapport motivé justifiant le diagnostic et la nécessité des soins. S’il le juge utile, le médecin-conseil envoie ce dossier pour avis au Collège des médecins-directeurs."
        }
      ]
    },
    {
      "code" : "e-l",
      "display" : "e-l",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "l) structurele anomalie van het locomotorisch stelsel, dat ernstige functionele stoornissen veroorzaakt, ten gevolge van een zeldzame aandoening, met andere woorden een aandoening waarvan de prevalentie kleiner is dan 5 op 10.000 inwoners. Deze aandoening is ofwel van inflammatoire of metabole aard ofwel is zij het gevolg van een groei- of ontwikkelingsstoornis.”"
        },
        {
          "language" : "fr-BE",
          "value" : "l) Anomalie structurelle du système locomoteur, occasionnant de graves troubles fonctionnels, sur base d’une affection rare, autrement dit dont la prévalence est inférieure à 5 pour 10.000 habitants. Cette affection est soit de nature inflammatoire ou métabolique, soit résultant d’un trouble de la croissance ou du développement."
        }
      ]
    },
    {
      "code" : "eb-1-1",
      "display" : "eb-1-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Uitgebreide perifere verlamming:monoplegie"
        },
        {
          "language" : "fr-BE",
          "value" : "Paralysie périphérique étendue Monoplégie"
        }
      ]
    },
    {
      "code" : "eb-1-2",
      "display" : "eb-1-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Uitgebreide perifere verlamming:syndroom van Guillain Barré"
        },
        {
          "language" : "fr-BE",
          "value" : "Paralysie périphérique étendue Syndrome de Guillain Barré"
        }
      ]
    },
    {
      "code" : "eb-1-3",
      "display" : "eb-1-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Uitgebreide perifere verlamming:erfelijke polyneuropathie (vb ziekte van Charcot-Marie-Tooth))"
        },
        {
          "language" : "fr-BE",
          "value" : "Paralysie périphérique étendue polyneuropathie héréditaire (ex. Maladie de Charcot-Marie-Tooth)"
        }
      ]
    },
    {
      "code" : "eb-2-1",
      "display" : "eb-2-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Evolutieve aandoeningen van het centrale zenuwstelsel met een uitgebreid motorisch gebrek:multiple sclerose"
        },
        {
          "language" : "fr-BE",
          "value" : "Affections neurologiques centrales de caractère évolutif avec déficit moteur étendusclérose en plaques"
        }
      ]
    },
    {
      "code" : "eb-2-2",
      "display" : "eb-2-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Evolutieve aandoeningen van het centrale zenuwstelsel met een uitgebreid motorisch gebrek:de ziekte van Parkinson"
        },
        {
          "language" : "fr-BE",
          "value" : "Affections neurologiques centrales de caractère évolutif avec déficit moteur étendumaladie de Parkinson"
        }
      ]
    },
    {
      "code" : "eb-2-3",
      "display" : "eb-2-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Evolutieve aandoeningen van het centrale zenuwstelsel met een uitgebreid motorisch gebrek:Multipele Systeem Atrofie (in alle vormen)"
        },
        {
          "language" : "fr-BE",
          "value" : "Affections neurologiques centrales de caractère évolutif avec déficit moteur étenduatrophies multisystématisées (toutes les formes)"
        }
      ]
    },
    {
      "code" : "eb-2-4",
      "display" : "eb-2-4",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Evolutieve aandoeningen van het centrale zenuwstelsel met een uitgebreid motorisch gebrek:Progressive Supranuclear Palsy, Corticobasal Degeneration"
        },
        {
          "language" : "fr-BE",
          "value" : "Affections neurologiques centrales de caractère évolutif avec déficit moteur étenduparalysie supranucléaire progressive, la dégénérescence corticobasale"
        }
      ]
    },
    {
      "code" : "eb-2-5",
      "display" : "eb-2-5",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Evolutieve aandoeningen van het centrale zenuwstelsel met een uitgebreid motorisch gebrek:syndromen die geklasseerd worden onder de Parkinson-Plus syndromen"
        },
        {
          "language" : "fr-BE",
          "value" : "Affections neurologiques centrales de caractère évolutif avec déficit moteur étenduautres syndromes classés sous les syndrômes dits « Parkinson-Plus »"
        }
      ]
    },
    {
      "code" : "eb-2-6",
      "display" : "eb-2-6",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Evolutieve aandoeningen van het centrale zenuwstelsel met een uitgebreid motorisch gebrek:de ziekte van Huntington"
        },
        {
          "language" : "fr-BE",
          "value" : "Affections neurologiques centrales de caractère évolutif avec déficit moteur étendumaladie de Huntington"
        }
      ]
    },
    {
      "code" : "eb-2-7",
      "display" : "eb-2-7",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Evolutieve aandoeningen van het centrale zenuwstelsel met een uitgebreid motorisch gebrek:amyotrofische laterale sclerose"
        },
        {
          "language" : "fr-BE",
          "value" : "Affections neurologiques centrales de caractère évolutif avec déficit moteur étendusclérose latérale amyotrophique"
        }
      ]
    },
    {
      "code" : "eb-2-8",
      "display" : "eb-2-8",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Evolutieve aandoeningen van het centrale zenuwstelsel met een uitgebreid motorisch gebrek:spinocerebellaire ataxie"
        },
        {
          "language" : "fr-BE",
          "value" : "Affections neurologiques centrales de caractère évolutif avec déficit moteur étenduataxie spinocérébellaire"
        }
      ]
    },
    {
      "code" : "eb-3-1",
      "display" : "eb-3-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Uitgebreide motorische sequellen van encefale of medullaire oorsprong:hersenverlamming \"Cerebral Palsy\""
        },
        {
          "language" : "fr-BE",
          "value" : "Séquelles motrices étendues d'origine encéphalique ou médullaire :infirmité motrice cérébrale \"Cerebral Palsy\""
        }
      ]
    },
    {
      "code" : "eb-3-2",
      "display" : "eb-3-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Uitgebreide motorische sequellen van encefale of medullaire oorsprong:cerebrovasculair accident"
        },
        {
          "language" : "fr-BE",
          "value" : "Séquelles motrices étendues d'origine encéphalique ou médullaire :accident vasculaire cérébral"
        }
      ]
    },
    {
      "code" : "eb-3-3",
      "display" : "eb-3-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Uitgebreide motorische sequellen van encefale of medullaire oorsprong:paraplegie (-parese), quadriplegie (-parese) onafhankelijk van de etiologie"
        },
        {
          "language" : "fr-BE",
          "value" : "Séquelles motrices étendues d'origine encéphalique ou médullaire :paraplégie (-parésie), quadriplégie (-parésie) quelque soit l’étiologie"
        }
      ]
    },
    {
      "code" : "eb-3-4",
      "display" : "eb-3-4",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Uitgebreide motorische sequellen van encefale of medullaire oorsprong:spina bifida"
        },
        {
          "language" : "fr-BE",
          "value" : "Séquelles motrices étendues d'origine encéphalique ou médullaire :spina bifida"
        }
      ]
    },
    {
      "code" : "eb-3-5",
      "display" : "eb-3-5",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Uitgebreide motorische sequellen van encefale of medullaire oorsprong:cerebellair syndroom"
        },
        {
          "language" : "fr-BE",
          "value" : "Séquelles motrices étendues d'origine encéphalique ou médullaire :syndrome cérébelleux"
        }
      ]
    },
    {
      "code" : "eb-3-6",
      "display" : "eb-3-6",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Uitgebreide motorische sequellen van encefale of medullaire oorsprong:infectieuze of auto-immune encefalitis"
        },
        {
          "language" : "fr-BE",
          "value" : "Séquelles motrices étendues d'origine encéphalique ou médullaire :encéphalite infectieuse ou auto-immune"
        }
      ]
    },
    {
      "code" : "eb-4",
      "display" : "eb-4",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Belangrijk functioneel verlies van een lidmaat ten gevolge van een agenesie van het lidmaat of van een dysmelie die de anatomie van zijn verschillende segmenten aantast"
        },
        {
          "language" : "fr-BE",
          "value" : "Perte fonctionnelle importante d’un membre suite à une agénésie du membre ou à une dysmélie affectant l’anatomie de ses différents segments"
        }
      ]
    },
    {
      "code" : "eb-5-1",
      "display" : "eb-5-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Ernstige gewrichtsdysfunctie ten gevolge van:hemofilie"
        },
        {
          "language" : "fr-BE",
          "value" : "Dysfonction articulaire grave résultant :hémophilie"
        }
      ]
    },
    {
      "code" : "eb-5-2-1",
      "display" : "eb-5-2-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Ernstige gewrichtsdysfunctie ten gevolge van:erfelijke bindweefselaandoeningen/osteogenesis imperfecta van het type III en IV"
        },
        {
          "language" : "fr-BE",
          "value" : "Dysfonction articulaire grave résultant :maladies héréditaires du tissu conjonctif/ostéogenèse imparfaite de type III et IV"
        }
      ]
    },
    {
      "code" : "eb-5-2-2",
      "display" : "eb-5-2-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Ernstige gewrichtsdysfunctie ten gevolge van:erfelijke bindweefselaandoeningen/Ehlers-Danlos-syndroom"
        },
        {
          "language" : "fr-BE",
          "value" : "Dysfonction articulaire grave résultant :maladies héréditaires du tissu conjonctif/syndrome d'Ehlers-Danlos"
        }
      ]
    },
    {
      "code" : "eb-5-2-3",
      "display" : "eb-5-2-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Ernstige gewrichtsdysfunctie ten gevolge van:erfelijke bindweefselaandoeningen/chondrodysplasieën"
        },
        {
          "language" : "fr-BE",
          "value" : "Dysfonction articulaire grave résultant :maladies héréditaires du tissu conjonctif/chondrodysplasies"
        }
      ]
    },
    {
      "code" : "eb-5-2-4",
      "display" : "eb-5-2-4",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Ernstige gewrichtsdysfunctie ten gevolge van:erfelijke bindweefselaandoeningen/Marfan-syndroom"
        },
        {
          "language" : "fr-BE",
          "value" : "Dysfonction articulaire grave résultant :maladies héréditaires du tissu conjonctif/syndrome deMarfan"
        }
      ]
    },
    {
      "code" : "eb-5-2-5",
      "display" : "eb-5-2-5",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Ernstige gewrichtsdysfunctie ten gevolge van:erfelijke bindweefselaandoeningen/Anders"
        },
        {
          "language" : "fr-BE",
          "value" : "Dysfonction articulaire grave résultant :maladies héréditaires du tissu conjonctif/Autre"
        }
      ]
    },
    {
      "code" : "eb-5-3",
      "display" : "eb-5-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Ernstige gewrichtsdysfunctie ten gevolge van:multipel congenitale arthrogrypose"
        },
        {
          "language" : "fr-BE",
          "value" : "Dysfonction articulaire grave résultant :arthrogrypose congénitale multiple"
        }
      ]
    },
    {
      "code" : "eb-6-1",
      "display" : "eb-6-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Ernstige stoornissen van de gewrichtsfunctie(s), die het gevolg zijn van een chronische autoimmune inflammatoire polyarthritis (volgens de definities aanvaard door de Koninklijke Belgische Vereniging voor Reumatologie):reumatoïde artritis"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles graves de la ou des fonctions articulaire(s), qui sont le résultat d’une polyarthrite chronique inflammatoire d’origine immunitaire (selon les définitions acceptées par la Société Royale Belge de Rhumatologie)arthrite rhumatoïde"
        }
      ]
    },
    {
      "code" : "eb-6-2",
      "display" : "eb-6-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Ernstige stoornissen van de gewrichtsfunctie(s), die het gevolg zijn van een chronische autoimmune inflammatoire polyarthritis (volgens de definities aanvaard door de Koninklijke Belgische Vereniging voor Reumatologie):spondyloartropathie"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles graves de la ou des fonctions articulaire(s), qui sont le résultat d’une polyarthrite chronique inflammatoire d’origine immunitaire (selon les définitions acceptées par la Société Royale Belge de Rhumatologie)spondyloarthropathies"
        }
      ]
    },
    {
      "code" : "eb-6-3",
      "display" : "eb-6-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Ernstige stoornissen van de gewrichtsfunctie(s), die het gevolg zijn van een chronische autoimmune inflammatoire polyarthritis (volgens de definities aanvaard door de Koninklijke Belgische Vereniging voor Reumatologie):juveniele chronische artritis"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles graves de la ou des fonctions articulaire(s), qui sont le résultat d’une polyarthrite chronique inflammatoire d’origine immunitaire (selon les définitions acceptées par la Société Royale Belge de Rhumatologie)arthrite rhumatoïde juvénile"
        }
      ]
    },
    {
      "code" : "eb-6-4",
      "display" : "eb-6-4",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Ernstige stoornissen van de gewrichtsfunctie(s), die het gevolg zijn van een chronische autoimmune inflammatoire polyarthritis (volgens de definities aanvaard door de Koninklijke Belgische Vereniging voor Reumatologie):systemische lupus"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles graves de la ou des fonctions articulaire(s), qui sont le résultat d’une polyarthrite chronique inflammatoire d’origine immunitaire (selon les définitions acceptées par la Société Royale Belge de Rhumatologie)lupus erythémateux"
        }
      ]
    },
    {
      "code" : "eb-6-5",
      "display" : "eb-6-5",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Ernstige stoornissen van de gewrichtsfunctie(s), die het gevolg zijn van een chronische autoimmune inflammatoire polyarthritis (volgens de definities aanvaard door de Koninklijke Belgische Vereniging voor Reumatologie):sclerodermie"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles graves de la ou des fonctions articulaire(s), qui sont le résultat d’une polyarthrite chronique inflammatoire d’origine immunitaire (selon les définitions acceptées par la Société Royale Belge de Rhumatologie)sclérodermie"
        }
      ]
    },
    {
      "code" : "eb-6-6",
      "display" : "eb-6-6",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Ernstige stoornissen van de gewrichtsfunctie(s), die het gevolg zijn van een chronische autoimmune inflammatoire polyarthritis (volgens de definities aanvaard door de Koninklijke Belgische Vereniging voor Reumatologie):primair syndroom van Sjögren"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles graves de la ou des fonctions articulaire(s), qui sont le résultat d’une polyarthrite chronique inflammatoire d’origine immunitaire (selon les définitions acceptées par la Société Royale Belge de Rhumatologie)syndrome de Sjögren primaire"
        }
      ]
    },
    {
      "code" : "eb-7-1",
      "display" : "eb-7-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Myopathieën:erfelijke evolutieve myopathieën (waaronder de spierziekte van Duchenne,…)"
        },
        {
          "language" : "fr-BE",
          "value" : "Myopathies : myopathies héréditaires évolutives (dont la dystrophie musculaire de Duchenne…)"
        }
      ]
    },
    {
      "code" : "eb-7-2",
      "display" : "eb-7-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Myopathieën:myotone dystrofie (onder andere de ziekte van Steinert,…)"
        },
        {
          "language" : "fr-BE",
          "value" : "Myopathies : dystrophies myotoniques (dont la maladie de Steinert,…)"
        }
      ]
    },
    {
      "code" : "eb-7-3",
      "display" : "eb-7-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Myopathieën:myotonia congenita (onder andere de ziekte van Thomsen,…)"
        },
        {
          "language" : "fr-BE",
          "value" : "Myopathies : myotonie congénitale (dont la maladie de Thomsen,…)"
        }
      ]
    },
    {
      "code" : "eb-7-4",
      "display" : "eb-7-4",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Myopathieën:auto-immune polymyositis"
        },
        {
          "language" : "fr-BE",
          "value" : "Myopathies : Polymyosite auto-immune"
        }
      ]
    },
    {
      "code" : "eb-8",
      "display" : "eb-8",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Mucoviscidose of geobjectiveerde primaire bronchiale ciliaire dyskinesie"
        },
        {
          "language" : "fr-BE",
          "value" : "Mucoviscidose ou dyskinésie ciliaire bronchiale primaire objectivées"
        }
      ]
    },
    {
      "code" : "eb-9",
      "display" : "eb-9",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Geobjectiveerde hyperproductieve bronchiectasieën"
        },
        {
          "language" : "fr-BE",
          "value" : "Bronchiectasies hyperproductives objectivées"
        }
      ]
    },
    {
      "code" : "eb-10",
      "display" : "eb-10",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Irreversibele chronische obstructieve of restrictieve longaandoeningen met maximum expiratoire secondecapaciteit waarden van minder dan of gelijk aan 60 pct., opgemeten in een tussenperiode van minstens één maand; bij een kind jonger dan 7 jaar kan de irreversibele ademhalingsinsufficiëntie worden vastgesteld op basis van een gemotiveerd verslag van de behandelende specialist"
        },
        {
          "language" : "fr-BE",
          "value" : "Affections pulmonaires chroniques irréversibles obstructives ou restrictives avec des valeurs de volume expiratoire maximum-seconde inférieures ou égales à 60 % mesurées à un intervalle d'au moins 1 mois ; chez un enfant de moins de 7 ans, l'insuffisance respiratoire irréversible pourra être établie sur base d'un rapport motivé du spécialiste traitant"
        }
      ]
    },
    {
      "code" : "eb-11",
      "display" : "eb-11",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Recidiverende pulmonaire infecties bij bewezen ernstige immunodepressie"
        },
        {
          "language" : "fr-BE",
          "value" : "Infections pulmonaires récidivantes en cas d'immunodépression grave établie"
        }
      ]
    },
    {
      "code" : "eb-12",
      "display" : "eb-12",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Broncho-pulmonaire dysplasie met zuurstofafhankelijkheid gedurende meer dan 28 dagen"
        },
        {
          "language" : "fr-BE",
          "value" : "Dysplasie broncho-pulmonaire avec oxygénodépendance de plus de 28 jours"
        }
      ]
    },
    {
      "code" : "eb-13",
      "display" : "eb-13",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Epidermolysis bullosa in de dystrofische of junctionele vorm"
        },
        {
          "language" : "fr-BE",
          "value" : "Épidermolyse bulleuse dans la forme dystrophique ou jonctionnelle"
        }
      ]
    },
    {
      "code" : "m-1",
      "display" : "m-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Pre en/of post-partum zorgen"
        },
        {
          "language" : "fr-BE",
          "value" : "Soins pré et/ou post partum"
        }
      ]
    },
    {
      "code" : "p-1",
      "display" : "p-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Paliatieve zorgen"
        },
        {
          "language" : "fr-BE",
          "value" : "Soins palliatifs"
        }
      ]
    },
    {
      "code" : "dh-1",
      "display" : "dh-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Daghospitalisatie"
        },
        {
          "language" : "fr-BE",
          "value" : "Hospitalisation de jour"
        }
      ]
    },
    {
      "code" : "cr-1",
      "display" : "cr-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Consultatief onderzoek"
        },
        {
          "language" : "fr-BE",
          "value" : "Examen consultatif"
        }
      ]
    },
    {
      "code" : "co-0-0-0-0",
      "display" : "co-0-0-0-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "n/a n/a Onbepaalde pathologische situatie (papieren akkoord) -"
        },
        {
          "language" : "fr-BE",
          "value" : "n/a n/a Situation pathologique non définie (accord papier) -"
        }
      ]
    },
    {
      "code" : "co-1-1-1-0",
      "display" : "co-1-1-1-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Nek- Cervicaal  Artrose -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Nuque - Cervical Arthrose -"
        }
      ]
    },
    {
      "code" : "co-1-1-2-0",
      "display" : "co-1-1-2-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Nek- Cervicaal  Discopathie, Discushernia -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Nuque - Cervical Discopathie, Hernie discale -"
        }
      ]
    },
    {
      "code" : "co-1-1-3-0",
      "display" : "co-1-1-3-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Nek- Cervicaal  Spinaal kanaalstenose -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Nuque - Cervical Sténose du canal rachidien -"
        }
      ]
    },
    {
      "code" : "co-1-1-4-0",
      "display" : "co-1-1-4-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Nek- Cervicaal  Cervico-brachialgie -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Nuque - Cervical Cervico-brachialgie -"
        }
      ]
    },
    {
      "code" : "co-1-1-5-0",
      "display" : "co-1-1-5-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Nek- Cervicaal  Occipitalgie, Occipitalisneuralgie, Spanningshoofdpijn, Migraine -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Nuque - Cervical Occipitalgie, Névralgie occipitale, Céphalée de tension, Migraine -"
        }
      ]
    },
    {
      "code" : "co-1-1-6-0",
      "display" : "co-1-1-6-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Nek- Cervicaal  Torticollis -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Nuque - Cervical Torticolis -"
        }
      ]
    },
    {
      "code" : "co-1-1-7-0",
      "display" : "co-1-1-7-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Nek- Cervicaal  Trapeziussyndroom -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Nuque - Cervical Syndrome du trapèze -"
        }
      ]
    },
    {
      "code" : "co-1-1-8-0",
      "display" : "co-1-1-8-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Nek- Cervicaal  Whiplash -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Nuque - Cervical Coup de fouet -"
        }
      ]
    },
    {
      "code" : "co-1-1-90-0",
      "display" : "co-1-1-90-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Nek- Cervicaal  Fraktuur  -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Nuque - Cervical Fracture -"
        }
      ]
    },
    {
      "code" : "co-1-1-99-0",
      "display" : "co-1-1-99-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Nek- Cervicaal  Andere (ook uit F-E-11bis) -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Nuque - Cervical Autre (également de F-E-11bis) -"
        }
      ]
    },
    {
      "code" : "co-1-2-1-0",
      "display" : "co-1-2-1-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Thoracaal) Artrose -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Thoracique) Arthrose -"
        }
      ]
    },
    {
      "code" : "co-1-2-2-0",
      "display" : "co-1-2-2-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Thoracaal) Discopathie, Discushernia -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Thoracique) Discopathie, Hernie discale -"
        }
      ]
    },
    {
      "code" : "co-1-2-3-0",
      "display" : "co-1-2-3-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Thoracaal) Spinaal kanaal stenose -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Thoracique) Sténose du canal rachidien -"
        }
      ]
    },
    {
      "code" : "co-1-2-4-0",
      "display" : "co-1-2-4-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Thoracaal) Dorsalgie -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Thoracique) Dorsalgie -"
        }
      ]
    },
    {
      "code" : "co-1-2-5-0",
      "display" : "co-1-2-5-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Thoracaal) Dorsaal radiculair syndroom, Radiculopathie -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Thoracique) Syndrome radiculaire dorsal, Radiculopathie -"
        }
      ]
    },
    {
      "code" : "co-1-2-6-0",
      "display" : "co-1-2-6-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Thoracaal) (Kyfo)scoliose -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Thoracique) (Kyfo)scoliose -"
        }
      ]
    },
    {
      "code" : "co-1-2-90-0",
      "display" : "co-1-2-90-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Thoracaal) Fraktuur  -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Thoracique) Fracture -"
        }
      ]
    },
    {
      "code" : "co-1-2-99-0",
      "display" : "co-1-2-99-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Thoracaal) Andere (ook uit F-E-11bis) -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Thoracique) Autre (également de F-E-11bis) -"
        }
      ]
    },
    {
      "code" : "co-1-3-1-0",
      "display" : "co-1-3-1-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Lumbaal - Sacraal) Artrose -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Lombo-sacral) Arthrose -"
        }
      ]
    },
    {
      "code" : "co-1-3-2-0",
      "display" : "co-1-3-2-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Lumbaal - Sacraal) Discopathie, Discushernia -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Lombo-sacral) Discopathie, Hernie discale -"
        }
      ]
    },
    {
      "code" : "co-1-3-3-0",
      "display" : "co-1-3-3-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Lumbaal - Sacraal) Spinaal kanaal stenose -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Lombo-sacral) Sténose du canal rachidien -"
        }
      ]
    },
    {
      "code" : "co-1-3-4-0",
      "display" : "co-1-3-4-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Lumbaal - Sacraal) Lage rugpijn, Lumbalgie -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Lombo-sacral) Lombalgie -"
        }
      ]
    },
    {
      "code" : "co-1-3-5-0",
      "display" : "co-1-3-5-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Lumbaal - Sacraal) Lumbo-ischialgie -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Lombo-sacral) Lombo sciatique -"
        }
      ]
    },
    {
      "code" : "co-1-3-6-0",
      "display" : "co-1-3-6-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Lumbaal - Sacraal) Lumbosacraal radiculair syndroom, Radiculopathie -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Lombo-sacral) Syndrome radiculaire lombo-sacré, Radiculopathie -"
        }
      ]
    },
    {
      "code" : "co-1-3-7-0",
      "display" : "co-1-3-7-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Lumbaal - Sacraal) Sacro-iliac disorder -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Lombo-sacral) Trouble sacro-iliaque -"
        }
      ]
    },
    {
      "code" : "co-1-3-8-0",
      "display" : "co-1-3-8-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Lumbaal - Sacraal) Spondylolisthesis, Spondylolyse -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Lombo-sacral) Spondylolisthésis, Spondylolyse -"
        }
      ]
    },
    {
      "code" : "co-1-3-90-0",
      "display" : "co-1-3-90-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Lumbaal - Sacraal) Fraktuur  -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Lombo-sacral) Fracture -"
        }
      ]
    },
    {
      "code" : "co-1-3-99-0",
      "display" : "co-1-3-99-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Wervelzuil Rug (Lumbaal - Sacraal) Andere (ook uit F-E-11bis) -"
        },
        {
          "language" : "fr-BE",
          "value" : "Colonne vertébrale Dos (Lombo-sacral) Autre (également de F-E-11bis) -"
        }
      ]
    },
    {
      "code" : "co-2-1-1-1",
      "display" : "co-2-1-1-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Artrose Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Arthrose Gauche"
        }
      ]
    },
    {
      "code" : "co-2-1-1-2",
      "display" : "co-2-1-1-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Artrose Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Arthrose Droit"
        }
      ]
    },
    {
      "code" : "co-2-1-1-3",
      "display" : "co-2-1-1-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Artrose Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Arthrose Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-1-2-1",
      "display" : "co-2-1-2-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Gauche"
        }
      ]
    },
    {
      "code" : "co-2-1-2-2",
      "display" : "co-2-1-2-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Droit"
        }
      ]
    },
    {
      "code" : "co-2-1-2-3",
      "display" : "co-2-1-2-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-1-3-1",
      "display" : "co-2-1-3-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm (Rotator)cuff lijden  Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Lésion de la coiffe (des rotateurs) Gauche"
        }
      ]
    },
    {
      "code" : "co-2-1-3-2",
      "display" : "co-2-1-3-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm (Rotator)cuff lijden  Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Lésion de la coiffe (des rotateurs) Droit"
        }
      ]
    },
    {
      "code" : "co-2-1-3-3",
      "display" : "co-2-1-3-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm (Rotator)cuff lijden  Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Lésion de la coiffe (des rotateurs) Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-1-4-1",
      "display" : "co-2-1-4-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Inpingement Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Pincement Gauche"
        }
      ]
    },
    {
      "code" : "co-2-1-4-2",
      "display" : "co-2-1-4-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Inpingement Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Pincement Droit"
        }
      ]
    },
    {
      "code" : "co-2-1-4-3",
      "display" : "co-2-1-4-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Inpingement Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Pincement Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-1-5-1",
      "display" : "co-2-1-5-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Luxatie Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Luxation Gauche"
        }
      ]
    },
    {
      "code" : "co-2-1-5-2",
      "display" : "co-2-1-5-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Luxatie Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Luxation Droit"
        }
      ]
    },
    {
      "code" : "co-2-1-5-3",
      "display" : "co-2-1-5-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Luxatie Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Luxation Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-1-6-1",
      "display" : "co-2-1-6-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Thoracic Outlet Syndroom Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Syndrome du défilé thoraco-brachial (Thoracic Outlet Syndrome) Gauche"
        }
      ]
    },
    {
      "code" : "co-2-1-6-2",
      "display" : "co-2-1-6-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Thoracic Outlet Syndroom Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Syndrome du défilé thoraco-brachial (Thoracic Outlet Syndrome) Droit"
        }
      ]
    },
    {
      "code" : "co-2-1-6-3",
      "display" : "co-2-1-6-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Thoracic Outlet Syndroom Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Syndrome du défilé thoraco-brachial (Thoracic Outlet Syndrome) Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-1-90-1",
      "display" : "co-2-1-90-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Fraktuur  Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Fracture Gauche"
        }
      ]
    },
    {
      "code" : "co-2-1-90-2",
      "display" : "co-2-1-90-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Fraktuur  Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Fracture Droit"
        }
      ]
    },
    {
      "code" : "co-2-1-90-3",
      "display" : "co-2-1-90-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Fraktuur  Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Fracture Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-1-99-1",
      "display" : "co-2-1-99-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Andere (ook uit F-E-11bis) Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Autre (également de F-E-11bis) Gauche"
        }
      ]
    },
    {
      "code" : "co-2-1-99-2",
      "display" : "co-2-1-99-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Andere (ook uit F-E-11bis) Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Autre (également de F-E-11bis) Droit"
        }
      ]
    },
    {
      "code" : "co-2-1-99-3",
      "display" : "co-2-1-99-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Schouder - Bovenarm Andere (ook uit F-E-11bis) Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Epaule - Haut du bras Autre (également de F-E-11bis) Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-2-1-1",
      "display" : "co-2-2-1-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Artrose Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Arthrose Gauche"
        }
      ]
    },
    {
      "code" : "co-2-2-1-2",
      "display" : "co-2-2-1-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Artrose Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Arthrose Droit"
        }
      ]
    },
    {
      "code" : "co-2-2-1-3",
      "display" : "co-2-2-1-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Artrose Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Arthrose Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-2-2-1",
      "display" : "co-2-2-2-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Gauche"
        }
      ]
    },
    {
      "code" : "co-2-2-2-2",
      "display" : "co-2-2-2-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Droit"
        }
      ]
    },
    {
      "code" : "co-2-2-2-3",
      "display" : "co-2-2-2-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-2-3-1",
      "display" : "co-2-2-3-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Epicondylitis medialis, Tenniselleboog Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Epicondylite médiale, Tennis elbow Gauche"
        }
      ]
    },
    {
      "code" : "co-2-2-3-2",
      "display" : "co-2-2-3-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Epicondylitis medialis, Tenniselleboog Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Epicondylite médiale, Tennis elbow Droit"
        }
      ]
    },
    {
      "code" : "co-2-2-3-3",
      "display" : "co-2-2-3-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Epicondylitis medialis, Tenniselleboog Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Epicondylite médiale, Tennis elbow Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-2-4-1",
      "display" : "co-2-2-4-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Epicondylitis ulnaris, Golferselleboog Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Epicondylite ulnaire, Coude du golfeur Gauche"
        }
      ]
    },
    {
      "code" : "co-2-2-4-2",
      "display" : "co-2-2-4-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Epicondylitis ulnaris, Golferselleboog Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Epicondylite ulnaire, Coude du golfeur Droit"
        }
      ]
    },
    {
      "code" : "co-2-2-4-3",
      "display" : "co-2-2-4-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Epicondylitis ulnaris, Golferselleboog Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Epicondylite ulnaire, Coude du golfeur Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-2-5-1",
      "display" : "co-2-2-5-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Repetitive strain injury (RSI) Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Microtraumatismes répétés (RSI) Gauche"
        }
      ]
    },
    {
      "code" : "co-2-2-5-2",
      "display" : "co-2-2-5-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Repetitive strain injury (RSI) Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Microtraumatismes répétés (RSI) Droit"
        }
      ]
    },
    {
      "code" : "co-2-2-5-3",
      "display" : "co-2-2-5-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Repetitive strain injury (RSI) Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Microtraumatismes répétés (RSI) Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-2-90-1",
      "display" : "co-2-2-90-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Fraktuur  Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Fracture Gauche"
        }
      ]
    },
    {
      "code" : "co-2-2-90-2",
      "display" : "co-2-2-90-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Fraktuur  Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Fracture Droit"
        }
      ]
    },
    {
      "code" : "co-2-2-90-3",
      "display" : "co-2-2-90-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Fraktuur  Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Fracture Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-2-99-1",
      "display" : "co-2-2-99-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Andere (ook uit F-E-11bis) Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Autre (également de F-E-11bis) Gauche"
        }
      ]
    },
    {
      "code" : "co-2-2-99-2",
      "display" : "co-2-2-99-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Andere (ook uit F-E-11bis) Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Autre (également de F-E-11bis) Droit"
        }
      ]
    },
    {
      "code" : "co-2-2-99-3",
      "display" : "co-2-2-99-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Elleboog - Onderarm Andere (ook uit F-E-11bis) Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Coude - Avant-bras Autre (également de F-E-11bis) Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-3-1-1",
      "display" : "co-2-3-1-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Artrose Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Arthrose Gauche"
        }
      ]
    },
    {
      "code" : "co-2-3-1-2",
      "display" : "co-2-3-1-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Artrose Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Arthrose Droit"
        }
      ]
    },
    {
      "code" : "co-2-3-1-3",
      "display" : "co-2-3-1-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Artrose Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Arthrose Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-3-2-1",
      "display" : "co-2-3-2-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Gauche"
        }
      ]
    },
    {
      "code" : "co-2-3-2-2",
      "display" : "co-2-3-2-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Droit"
        }
      ]
    },
    {
      "code" : "co-2-3-2-3",
      "display" : "co-2-3-2-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-3-3-1",
      "display" : "co-2-3-3-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Carpal-tunnelsyndroom Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Syndrome du canal carpien Gauche"
        }
      ]
    },
    {
      "code" : "co-2-3-3-2",
      "display" : "co-2-3-3-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Carpal-tunnelsyndroom Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Syndrome du canal carpien Droit"
        }
      ]
    },
    {
      "code" : "co-2-3-3-3",
      "display" : "co-2-3-3-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Carpal-tunnelsyndroom Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Syndrome du canal carpien Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-3-4-1",
      "display" : "co-2-3-4-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand De Quervain's, Dupuytren Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main De Quervain, Dupuytren Gauche"
        }
      ]
    },
    {
      "code" : "co-2-3-4-2",
      "display" : "co-2-3-4-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand De Quervain's, Dupuytren Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main De Quervain, Dupuytren Droit"
        }
      ]
    },
    {
      "code" : "co-2-3-4-3",
      "display" : "co-2-3-4-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand De Quervain's, Dupuytren Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main De Quervain, Dupuytren Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-3-5-1",
      "display" : "co-2-3-5-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Repetitive strain injury (RSI) Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Microtraumatismes répétés (RSI) Gauche"
        }
      ]
    },
    {
      "code" : "co-2-3-5-2",
      "display" : "co-2-3-5-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Repetitive strain injury (RSI) Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Microtraumatismes répétés (RSI) Droit"
        }
      ]
    },
    {
      "code" : "co-2-3-5-3",
      "display" : "co-2-3-5-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Repetitive strain injury (RSI) Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Microtraumatismes répétés (RSI) Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-3-90-1",
      "display" : "co-2-3-90-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Fraktuur  Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Fracture Gauche"
        }
      ]
    },
    {
      "code" : "co-2-3-90-2",
      "display" : "co-2-3-90-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Fraktuur  Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Fracture Droit"
        }
      ]
    },
    {
      "code" : "co-2-3-90-3",
      "display" : "co-2-3-90-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Fraktuur  Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Fracture Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-2-3-99-1",
      "display" : "co-2-3-99-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Andere (ook uit F-E-11bis) Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Autre (également de F-E-11bis) Gauche"
        }
      ]
    },
    {
      "code" : "co-2-3-99-2",
      "display" : "co-2-3-99-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Andere (ook uit F-E-11bis) Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Autre (également de F-E-11bis) Droit"
        }
      ]
    },
    {
      "code" : "co-2-3-99-3",
      "display" : "co-2-3-99-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Bovenste extremiteit Pols - Hand Andere (ook uit F-E-11bis) Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre supérieur Poignet - Main Autre (également de F-E-11bis) Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-1-1-1",
      "display" : "co-3-1-1-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Artrose Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Arthrose Gauche"
        }
      ]
    },
    {
      "code" : "co-3-1-1-2",
      "display" : "co-3-1-1-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Artrose Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Arthrose Droit"
        }
      ]
    },
    {
      "code" : "co-3-1-1-3",
      "display" : "co-3-1-1-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Artrose Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Arthrose Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-1-2-1",
      "display" : "co-3-1-2-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Gauche"
        }
      ]
    },
    {
      "code" : "co-3-1-2-2",
      "display" : "co-3-1-2-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Droit"
        }
      ]
    },
    {
      "code" : "co-3-1-2-3",
      "display" : "co-3-1-2-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-1-3-1",
      "display" : "co-3-1-3-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen FAI (femoro-acetabulair impingement), CAM, PINCER Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse FAI (conflit fémoro-acétabulaire), CAM, PINCER Gauche"
        }
      ]
    },
    {
      "code" : "co-3-1-3-2",
      "display" : "co-3-1-3-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen FAI (femoro-acetabulair impingement), CAM, PINCER Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse FAI (conflit fémoro-acétabulaire), CAM, PINCER Droit"
        }
      ]
    },
    {
      "code" : "co-3-1-3-3",
      "display" : "co-3-1-3-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen FAI (femoro-acetabulair impingement), CAM, PINCER Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse FAI (conflit fémoro-acétabulaire), CAM, PINCER Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-1-4-1",
      "display" : "co-3-1-4-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Heupluxatie Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Luxation de la hanche Gauche"
        }
      ]
    },
    {
      "code" : "co-3-1-4-2",
      "display" : "co-3-1-4-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Heupluxatie Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Luxation de la hanche Droit"
        }
      ]
    },
    {
      "code" : "co-3-1-4-3",
      "display" : "co-3-1-4-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Heupluxatie Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Luxation de la hanche Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-1-5-1",
      "display" : "co-3-1-5-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Liespijn, Snapping Hip, Pubalgie Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Douleur à l'aine, Claquage de la hanche, Pubalgie Gauche"
        }
      ]
    },
    {
      "code" : "co-3-1-5-2",
      "display" : "co-3-1-5-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Liespijn, Snapping Hip, Pubalgie Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Douleur à l'aine, Claquage de la hanche, Pubalgie Droit"
        }
      ]
    },
    {
      "code" : "co-3-1-5-3",
      "display" : "co-3-1-5-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Liespijn, Snapping Hip, Pubalgie Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Douleur à l'aine, Claquage de la hanche, Pubalgie Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-1-6-1",
      "display" : "co-3-1-6-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Heupdysplasie Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Dysplasie de la hanche Gauche"
        }
      ]
    },
    {
      "code" : "co-3-1-6-2",
      "display" : "co-3-1-6-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Heupdysplasie Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Dysplasie de la hanche Droit"
        }
      ]
    },
    {
      "code" : "co-3-1-6-3",
      "display" : "co-3-1-6-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Heupdysplasie Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Dysplasie de la hanche Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-1-90-1",
      "display" : "co-3-1-90-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Fraktuur  Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Fracture Gauche"
        }
      ]
    },
    {
      "code" : "co-3-1-90-2",
      "display" : "co-3-1-90-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Fraktuur  Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Fracture Droit"
        }
      ]
    },
    {
      "code" : "co-3-1-90-3",
      "display" : "co-3-1-90-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Fraktuur  Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Fracture Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-1-99-1",
      "display" : "co-3-1-99-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Andere (ook uit F-E-11bis) Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Autre (également de F-E-11bis) Gauche"
        }
      ]
    },
    {
      "code" : "co-3-1-99-2",
      "display" : "co-3-1-99-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Andere (ook uit F-E-11bis) Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Autre (également de F-E-11bis) Droit"
        }
      ]
    },
    {
      "code" : "co-3-1-99-3",
      "display" : "co-3-1-99-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Bekken - Heup - Bovenbeen Andere (ook uit F-E-11bis) Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bassin - Hanche - Cuisse Autre (également de F-E-11bis) Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-1-1",
      "display" : "co-3-2-1-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Artrose Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Arthrose Gauche"
        }
      ]
    },
    {
      "code" : "co-3-2-1-2",
      "display" : "co-3-2-1-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Artrose Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Arthrose Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-1-3",
      "display" : "co-3-2-1-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Artrose Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Arthrose Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-2-1",
      "display" : "co-3-2-2-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Gauche"
        }
      ]
    },
    {
      "code" : "co-3-2-2-2",
      "display" : "co-3-2-2-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-2-3",
      "display" : "co-3-2-2-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-3-1",
      "display" : "co-3-2-3-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Dislocatie van patellofemoraal gewricht, Patellaluxatie Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Luxation de l'articulation fémoro-patellaire, luxation rotulienne Gauche"
        }
      ]
    },
    {
      "code" : "co-3-2-3-2",
      "display" : "co-3-2-3-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Dislocatie van patellofemoraal gewricht, Patellaluxatie Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Luxation de l'articulation fémoro-patellaire, luxation rotulienne Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-3-3",
      "display" : "co-3-2-3-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Dislocatie van patellofemoraal gewricht, Patellaluxatie Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Luxation de l'articulation fémoro-patellaire, luxation rotulienne Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-4-1",
      "display" : "co-3-2-4-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Instabiliteit Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Instabilité Gauche"
        }
      ]
    },
    {
      "code" : "co-3-2-4-2",
      "display" : "co-3-2-4-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Instabiliteit Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Instabilité Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-4-3",
      "display" : "co-3-2-4-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Instabiliteit Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Instabilité Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-5-1",
      "display" : "co-3-2-5-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Ligamentair letsel, Peesletsel Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Lésion ligamentaire, Lésion tendineuse Gauche"
        }
      ]
    },
    {
      "code" : "co-3-2-5-2",
      "display" : "co-3-2-5-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Ligamentair letsel, Peesletsel Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Lésion ligamentaire, Lésion tendineuse Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-5-3",
      "display" : "co-3-2-5-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Ligamentair letsel, Peesletsel Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Lésion ligamentaire, Lésion tendineuse Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-6-1",
      "display" : "co-3-2-6-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Meniscusletsel Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Lésion du ménisque Gauche"
        }
      ]
    },
    {
      "code" : "co-3-2-6-2",
      "display" : "co-3-2-6-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Meniscusletsel Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Lésion du ménisque Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-6-3",
      "display" : "co-3-2-6-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Meniscusletsel Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Lésion du ménisque Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-7-1",
      "display" : "co-3-2-7-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Patellofemoraal letsel, Chondromalacie Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Lésion fémoro-patellaire, Chondromalacie Gauche"
        }
      ]
    },
    {
      "code" : "co-3-2-7-2",
      "display" : "co-3-2-7-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Patellofemoraal letsel, Chondromalacie Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Lésion fémoro-patellaire, Chondromalacie Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-7-3",
      "display" : "co-3-2-7-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Patellofemoraal letsel, Chondromalacie Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Lésion fémoro-patellaire, Chondromalacie Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-90-1",
      "display" : "co-3-2-90-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Fraktuur  Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Fracture Gauche"
        }
      ]
    },
    {
      "code" : "co-3-2-90-2",
      "display" : "co-3-2-90-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Fraktuur  Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Fracture Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-90-3",
      "display" : "co-3-2-90-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Fraktuur  Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Fracture Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-99-1",
      "display" : "co-3-2-99-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Andere (ook uit F-E-11bis) Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Autre (également de F-E-11bis) Gauche"
        }
      ]
    },
    {
      "code" : "co-3-2-99-2",
      "display" : "co-3-2-99-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Andere (ook uit F-E-11bis) Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Autre (également de F-E-11bis) Droit"
        }
      ]
    },
    {
      "code" : "co-3-2-99-3",
      "display" : "co-3-2-99-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Knie Andere (ook uit F-E-11bis) Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Genou Autre (également de F-E-11bis) Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-3-1-1",
      "display" : "co-3-3-1-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Artrose Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Arthrose Gauche"
        }
      ]
    },
    {
      "code" : "co-3-3-1-2",
      "display" : "co-3-3-1-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Artrose Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Arthrose Droit"
        }
      ]
    },
    {
      "code" : "co-3-3-1-3",
      "display" : "co-3-3-1-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Artrose Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Arthrose Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-3-2-1",
      "display" : "co-3-3-2-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Gauche"
        }
      ]
    },
    {
      "code" : "co-3-3-2-2",
      "display" : "co-3-3-2-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Droit"
        }
      ]
    },
    {
      "code" : "co-3-3-2-3",
      "display" : "co-3-3-2-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Letsel van spieren, pezen en/of zenuwen, Bursitis, Tendinitis, Strain, Contusie Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Lésion des muscles, des tendons et/ou des nerfs, Bursite, Tendinite, Foulure, Contusion Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-3-3-1",
      "display" : "co-3-3-3-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Distorsie, Verstuiking, Laxiteit, Inversietrauma, Ruptuur ligament Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Distorsion, Entorse, Laxité, Traumatisme d'inversion, Rupture ligamentaire Gauche"
        }
      ]
    },
    {
      "code" : "co-3-3-3-2",
      "display" : "co-3-3-3-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Distorsie, Verstuiking, Laxiteit, Inversietrauma, Ruptuur ligament Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Distorsion, Entorse, Laxité, Traumatisme d'inversion, Rupture ligamentaire Droit"
        }
      ]
    },
    {
      "code" : "co-3-3-3-3",
      "display" : "co-3-3-3-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Distorsie, Verstuiking, Laxiteit, Inversietrauma, Ruptuur ligament Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Distorsion, Entorse, Laxité, Traumatisme d'inversion, Rupture ligamentaire Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-3-4-1",
      "display" : "co-3-3-4-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Plantaire fasciitis Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Fasciite plantaire Gauche"
        }
      ]
    },
    {
      "code" : "co-3-3-4-2",
      "display" : "co-3-3-4-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Plantaire fasciitis Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Fasciite plantaire Droit"
        }
      ]
    },
    {
      "code" : "co-3-3-4-3",
      "display" : "co-3-3-4-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Plantaire fasciitis Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Fasciite plantaire Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-3-5-1",
      "display" : "co-3-3-5-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Pes planus, Pes valgus, Hallux valgus, Hielspoor, Klompvoet Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Pes planus, Pes valgus, Hallux valgus, Épine calcanéenne, Pied bot Gauche"
        }
      ]
    },
    {
      "code" : "co-3-3-5-2",
      "display" : "co-3-3-5-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Pes planus, Pes valgus, Hallux valgus, Hielspoor, Klompvoet Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Pes planus, Pes valgus, Hallux valgus, Épine calcanéenne, Pied bot Droit"
        }
      ]
    },
    {
      "code" : "co-3-3-5-3",
      "display" : "co-3-3-5-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Pes planus, Pes valgus, Hallux valgus, Hielspoor, Klompvoet Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Pes planus, Pes valgus, Hallux valgus, Épine calcanéenne, Pied bot Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-3-6-1",
      "display" : "co-3-3-6-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Shin splints Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Périostite tibiale Gauche"
        }
      ]
    },
    {
      "code" : "co-3-3-6-2",
      "display" : "co-3-3-6-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Shin splints Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Périostite tibiale Droit"
        }
      ]
    },
    {
      "code" : "co-3-3-6-3",
      "display" : "co-3-3-6-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Shin splints Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Périostite tibiale Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-3-90-1",
      "display" : "co-3-3-90-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Fraktuur  Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Fracture Gauche"
        }
      ]
    },
    {
      "code" : "co-3-3-90-2",
      "display" : "co-3-3-90-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Fraktuur  Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Fracture Droit"
        }
      ]
    },
    {
      "code" : "co-3-3-90-3",
      "display" : "co-3-3-90-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Fraktuur  Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Fracture Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-3-3-99-1",
      "display" : "co-3-3-99-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Andere (ook uit F-E-11bis) Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Autre (également de F-E-11bis) Gauche"
        }
      ]
    },
    {
      "code" : "co-3-3-99-2",
      "display" : "co-3-3-99-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Andere (ook uit F-E-11bis) Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Autre (également de F-E-11bis) Droit"
        }
      ]
    },
    {
      "code" : "co-3-3-99-3",
      "display" : "co-3-3-99-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Onderste extremiteit Onderbeen - Enkel - Voet Andere (ook uit F-E-11bis) Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Membre inférieur Bas de jambe - Cheville - Pied Autre (également de F-E-11bis) Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-4-1-90-0",
      "display" : "co-4-1-90-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Thorax - Fraktuur  -"
        },
        {
          "language" : "fr-BE",
          "value" : "Thorax - Fracture -"
        }
      ]
    },
    {
      "code" : "co-4-1-99-0",
      "display" : "co-4-1-99-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Thorax - Andere (ook uit F-E-11bis) -"
        },
        {
          "language" : "fr-BE",
          "value" : "Thorax - Autre (également de F-E-11bis) -"
        }
      ]
    },
    {
      "code" : "co-5-1-1-0",
      "display" : "co-5-1-1-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Longaandoeningen - Ademhalingsinsufficiëntie -"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles pulmonaires - Insuffisance respiratoire -"
        }
      ]
    },
    {
      "code" : "co-5-1-2-0",
      "display" : "co-5-1-2-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Longaandoeningen - COPD, Bronchitis, Bronchiolitis, Pneumonie, … -"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles pulmonaires - BPCO, Bronchite, Bronchiolite, Pneumonie, ... -"
        }
      ]
    },
    {
      "code" : "co-5-1-3-0",
      "display" : "co-5-1-3-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Longaandoeningen - Astma -"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles pulmonaires - Asthme -"
        }
      ]
    },
    {
      "code" : "co-5-1-4-0",
      "display" : "co-5-1-4-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Longaandoeningen - Hyperventilatie  -"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles pulmonaires - Hyperventilation -"
        }
      ]
    },
    {
      "code" : "co-5-1-99-0",
      "display" : "co-5-1-99-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Longaandoeningen - Andere (ook uit F-E-11bis) -"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles pulmonaires - Autre (également de F-E-11bis) -"
        }
      ]
    },
    {
      "code" : "co-6-1-1-0",
      "display" : "co-6-1-1-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Hart-, vaat- en lymfeaandoeningen - Post-hartinfarct  -"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles cardiovasculaires et lymphatiques - Post infarctus du myocarde -"
        }
      ]
    },
    {
      "code" : "co-6-1-2-1",
      "display" : "co-6-1-2-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Hart-, vaat- en lymfeaandoeningen - (Lymf)oedeem  Links"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles cardiovasculaires et lymphatiques - Oedème (lymphatique) Gauche"
        }
      ]
    },
    {
      "code" : "co-6-1-2-2",
      "display" : "co-6-1-2-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Hart-, vaat- en lymfeaandoeningen - (Lymf)oedeem  Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles cardiovasculaires et lymphatiques - Oedème (lymphatique) Droit"
        }
      ]
    },
    {
      "code" : "co-6-1-2-3",
      "display" : "co-6-1-2-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Hart-, vaat- en lymfeaandoeningen - (Lymf)oedeem  Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles cardiovasculaires et lymphatiques - Oedème (lymphatique) Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-6-1-3-0",
      "display" : "co-6-1-3-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Hart-, vaat- en lymfeaandoeningen - Transient cerebral ischaemic attack (TIA) -"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles cardiovasculaires et lymphatiques - Accident ischémique cérébral transitoire (TIA) -"
        }
      ]
    },
    {
      "code" : "co-6-1-4-0",
      "display" : "co-6-1-4-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Hart-, vaat- en lymfeaandoeningen - Claudicatio intermittens -"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles cardiovasculaires et lymphatiques - Claudication intermittente -"
        }
      ]
    },
    {
      "code" : "co-6-1-99-0",
      "display" : "co-6-1-99-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Hart-, vaat- en lymfeaandoeningen - Andere (ook uit F-E-11bis) -"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles cardiovasculaires et lymphatiques - Autre (également de F-E-11bis) -"
        }
      ]
    },
    {
      "code" : "co-7-1-1-0",
      "display" : "co-7-1-1-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Neurologische aandoeningen - Polyneuritis, Polyneuropathie -"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles neurologiques - Polynévrite, Polyneuropathie -"
        }
      ]
    },
    {
      "code" : "co-7-1-2-0",
      "display" : "co-7-1-2-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Neurologische aandoeningen - Intercostaal neuralgie, Zona, Herpes Zoster -"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles neurologiques - Névralgie intercostale, Zona, Herpes Zoster -"
        }
      ]
    },
    {
      "code" : "co-7-1-99-0",
      "display" : "co-7-1-99-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Neurologische aandoeningen - Andere (ook uit F-E-11bis) -"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles neurologiques - Autre (également de F-E-11bis) -"
        }
      ]
    },
    {
      "code" : "co-8-1-1-0",
      "display" : "co-8-1-1-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "ORL en aangezicht - Temporo-mandibulair syndroom -"
        },
        {
          "language" : "fr-BE",
          "value" : "ORL et visage - Syndrome temporo-mandibulaire -"
        }
      ]
    },
    {
      "code" : "co-8-1-2-0",
      "display" : "co-8-1-2-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "ORL en aangezicht - Bruxisme -"
        },
        {
          "language" : "fr-BE",
          "value" : "ORL et visage - Bruxisme -"
        }
      ]
    },
    {
      "code" : "co-8-1-3-1",
      "display" : "co-8-1-3-1",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "ORL en aangezicht - Uitval aangezichtszenuw Links"
        },
        {
          "language" : "fr-BE",
          "value" : "ORL et visage - Défaillance du nerf facial Gauche"
        }
      ]
    },
    {
      "code" : "co-8-1-3-2",
      "display" : "co-8-1-3-2",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "ORL en aangezicht - Uitval aangezichtszenuw Rechts"
        },
        {
          "language" : "fr-BE",
          "value" : "ORL et visage - Défaillance du nerf facial Droit"
        }
      ]
    },
    {
      "code" : "co-8-1-3-3",
      "display" : "co-8-1-3-3",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "ORL en aangezicht - Uitval aangezichtszenuw Beiden"
        },
        {
          "language" : "fr-BE",
          "value" : "ORL et visage - Défaillance du nerf facial Gauche et Droit"
        }
      ]
    },
    {
      "code" : "co-8-1-4-0",
      "display" : "co-8-1-4-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "ORL en aangezicht - Duizeligheid (Vertigo), Syndroom van Meniere -"
        },
        {
          "language" : "fr-BE",
          "value" : "ORL et visage - Vertiges, Syndrome de Ménière -"
        }
      ]
    },
    {
      "code" : "co-8-1-90-0",
      "display" : "co-8-1-90-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "ORL en aangezicht - Fraktuur  -"
        },
        {
          "language" : "fr-BE",
          "value" : "ORL et visage - Fracture -"
        }
      ]
    },
    {
      "code" : "co-8-1-99-0",
      "display" : "co-8-1-99-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "ORL en aangezicht - Andere (ook uit F-E-11bis) -"
        },
        {
          "language" : "fr-BE",
          "value" : "ORL et visage - Autre (également de F-E-11bis) -"
        }
      ]
    },
    {
      "code" : "co-9-1-1-0",
      "display" : "co-9-1-1-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Abdomen, inwendige aandoeningen en/of zwangerschap gerelateerd - Bekkeninstabiliteit, Symfysiolyse -"
        },
        {
          "language" : "fr-BE",
          "value" : "Abdomen, troubles internes et/ou liés à la grossesse - Instabilité pelvienne, Symphysiolyse -"
        }
      ]
    },
    {
      "code" : "co-9-1-2-0",
      "display" : "co-9-1-2-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Abdomen, inwendige aandoeningen en/of zwangerschap gerelateerd - Bekkenbodem reëducatie, Uro-Procto-Gynaeco, Incontinentie -"
        },
        {
          "language" : "fr-BE",
          "value" : "Abdomen, troubles internes et/ou liés à la grossesse - Rééducation du plancher pelvien, Uro-Procto-Gynaeco, Incontinence -"
        }
      ]
    },
    {
      "code" : "co-9-1-3-0",
      "display" : "co-9-1-3-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Abdomen, inwendige aandoeningen en/of zwangerschap gerelateerd - Buikspierscheur -"
        },
        {
          "language" : "fr-BE",
          "value" : "Abdomen, troubles internes et/ou liés à la grossesse - Déchirure des muscles abdominaux -"
        }
      ]
    },
    {
      "code" : "co-9-1-4-0",
      "display" : "co-9-1-4-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Abdomen, inwendige aandoeningen en/of zwangerschap gerelateerd - Aandoeningen in verband met zwangerschap (exclusief perinatale) -"
        },
        {
          "language" : "fr-BE",
          "value" : "Abdomen, troubles internes et/ou liés à la grossesse - Affections liées à la grossesse (hors périnatalité) -"
        }
      ]
    },
    {
      "code" : "co-9-1-99-0",
      "display" : "co-9-1-99-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Abdomen, inwendige aandoeningen en/of zwangerschap gerelateerd - Andere (ook uit F-E-11bis) -"
        },
        {
          "language" : "fr-BE",
          "value" : "Abdomen, troubles internes et/ou liés à la grossesse - Autre (également de F-E-11bis) -"
        }
      ]
    },
    {
      "code" : "co-10-1-1-0",
      "display" : "co-10-1-1-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Pediatrische aandoeningen - Motorische ontwikkelingsvertraging -"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles pédiatriques - Retard de développement moteur -"
        }
      ]
    },
    {
      "code" : "co-10-1-2-0",
      "display" : "co-10-1-2-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Pediatrische aandoeningen - Asymmetrische ontwikkeling -"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles pédiatriques - Développement asymétrique -"
        }
      ]
    },
    {
      "code" : "co-10-1-3-0",
      "display" : "co-10-1-3-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Pediatrische aandoeningen - Motorische onhandigheid -"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles pédiatriques - Maladresse motrice -"
        }
      ]
    },
    {
      "code" : "co-10-1-99-0",
      "display" : "co-10-1-99-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Pediatrische aandoeningen - Andere (ook uit F-E-11bis) -"
        },
        {
          "language" : "fr-BE",
          "value" : "Troubles pédiatriques - Autre (également de F-E-11bis) -"
        }
      ]
    },
    {
      "code" : "co-11-1-1-0",
      "display" : "co-11-1-1-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Andere - Gangrevalidatie bij afwijking van gang en/of beweeglijkheid -"
        },
        {
          "language" : "fr-BE",
          "value" : "Autre - Rééducation de la marche en cas de déviation de la marche et/ou de la mobilité -"
        }
      ]
    },
    {
      "code" : "co-11-1-2-0",
      "display" : "co-11-1-2-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Andere - Pré-operatieve kiné -"
        },
        {
          "language" : "fr-BE",
          "value" : "Autre - Kiné pré-opératoire -"
        }
      ]
    },
    {
      "code" : "co-11-1-3-0",
      "display" : "co-11-1-3-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Andere - Risicofactoren in de levensstijl (diabetes, obesitas, …) -"
        },
        {
          "language" : "fr-BE",
          "value" : "Autre - Facteurs de risque liés au mode de vie (diabète, obésité, …) -"
        }
      ]
    },
    {
      "code" : "co-11-1-4-0",
      "display" : "co-11-1-4-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Andere - Fibromyalgie, CVS, ME, SOLK, … -"
        },
        {
          "language" : "fr-BE",
          "value" : "Autre - Fibromyalgie, SFC, ME, MUS, ... -"
        }
      ]
    },
    {
      "code" : "co-11-1-5-0",
      "display" : "co-11-1-5-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Andere - Brandwonden, Littekens, … -"
        },
        {
          "language" : "fr-BE",
          "value" : "Autre -  Brûlures, Cicatrices, … -"
        }
      ]
    },
    {
      "code" : "co-11-1-6-0",
      "display" : "co-11-1-6-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Andere - Reconditionering na (algemene) spierzwakte -"
        },
        {
          "language" : "fr-BE",
          "value" : "Autre - Reconditionnement après une faiblesse musculaire (générale) -"
        }
      ]
    },
    {
      "code" : "co-11-1-7-0",
      "display" : "co-11-1-7-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Andere - Post-Covid -"
        },
        {
          "language" : "fr-BE",
          "value" : "Autre - Post-Covid -"
        }
      ]
    },
    {
      "code" : "co-11-1-99-0",
      "display" : "co-11-1-99-0",
      "designation" : [
        {
          "language" : "nl-BE",
          "value" : "Andere - Andere (ook uit F-E-11bis) -"
        },
        {
          "language" : "fr-BE",
          "value" : "Autre - Autre (également de F-E-11bis) -"
        }
      ]
    }
  ]
}

```
