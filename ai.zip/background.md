# Background - HL7 Belgium terminology Implementation Guide (IG) v1.0.0

* [**Table of Contents**](toc.md)
* **Background**

## Background

### Heading 1

 Some text 

### Heading 3

