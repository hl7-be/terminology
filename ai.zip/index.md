# Home - HL7 Belgium terminology Implementation Guide (IG) v1.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://hl7belgium.org/profiles/fhir/terminology/ImplementationGuide/hl7.fhir.be.terminology | *Version*:1.0.0 |
| Draft as of 2025-05-26 | *Computable Name*:BETerminology |

## NOT TO BE USED

**This implementation guide is not to be used**. It provides a collection of resources, but still lacks the ownership and governance associated with terminologies

