# Terminology Considerations - HL7 Belgium terminology Implementation Guide (IG) v1.0.0

* [**Table of Contents**](toc.md)
* **Terminology Considerations**

## Terminology Considerations

