# Population Screening Next Invitation Type - HL7 Belgium terminology Implementation Guide (IG) v1.0.0

## CodeSystem: Population Screening Next Invitation Type 

This Code system is referenced in the definition of the following value sets:

* [Population Screening Next Invitation Type Value Set](ValueSet-be-vs-populationscreening-next-invitation-type.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "be-cs-populationscreening-next-invitation-type",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1
  }],
  "url" : "https://www.ehealth.fgov.be/standards/fhir/public-health/CodeSystem/be-cs-populationscreening-next-invitation-type",
  "version" : "1.0.3",
  "name" : "BeCSPopulationScreeningNextInvitationType",
  "title" : "Population Screening Next Invitation Type",
  "status" : "active",
  "experimental" : false,
  "date" : "2024-06-12T10:56:47+02:00",
  "publisher" : "eHealth Platform",
  "contact" : [{
    "name" : "eHealth Platform",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ehealth.fgov.be/standards/fhir"
    },
    {
      "system" : "email",
      "value" : "support@be-ehealth-standards.atlassian.net"
    }]
  },
  {
    "name" : "eHealth Platform",
    "telecom" : [{
      "system" : "email",
      "value" : "support@be-ehealth-standards.atlassian.net",
      "use" : "work"
    }]
  }],
  "description" : "Code System containing the codes for the type of the next invitation (or exclusion of next invitation)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BE",
      "display" : "Belgium"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 7,
  "concept" : [{
    "code" : "nextinvitation",
    "display" : "A following invitation is expected"
  },
  {
    "code" : "definitivelyexcluded",
    "display" : "No further invitation expected"
  },
  {
    "code" : "notintargetgroup",
    "display" : "Not part of target group."
  },
  {
    "code" : "refusal",
    "display" : "No further invitations due to refusal."
  },
  {
    "code" : "temporarilyexcluded",
    "display" : "Temporarily excluded."
  },
  {
    "code" : "tobedetermined",
    "display" : "A further invitation may or not be advised, but that is not yet determined."
  },
  {
    "code" : "unknown",
    "display" : "Insufficient information to determine a future invitation."
  }]
}

```
