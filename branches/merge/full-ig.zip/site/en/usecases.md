# Use Cases - HL7 Belgium terminology Implementation Guide (IG) v1.0.0

## Use Cases

