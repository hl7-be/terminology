# BeCivilState - HL7 Belgium terminology Implementation Guide (IG) v1.0.0

## ValueSet: BeCivilState 

 
Codes supported by eHealth Platform differentiating types of civil state. This valueset supports the Belgian federal FHIR profiling effort. Whenever possible add a code from http://terminology.hl7.org/CodeSystem/v3-MaritalStatus for international interoperability but also use https://www.ehealth.fgov.be/standards/fhir/core/CodeSystem/CD-CIVILSTATE for the Belgian specific code. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

**Replaces.** This value set is the successor to, and replaces, the following resource(s) defined in earlier eHealth / HL7 Belgium FHIR specifications:

* [https://www.ehealth.fgov.be/standards/fhir/core/ValueSet/be-civilstate](https://www.ehealth.fgov.be/standards/fhir/core/ValueSet/be-civilstate)

The relationship is also machine-readable: the artefact carries an `artifact-relatedArtifact` extension whose `RelatedArtifact.type` is `predecessor`, pointing at the same URL.

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "be-civilstate",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-relatedArtifact",
    "valueRelatedArtifact" : {
      "type" : "predecessor",
      "resource" : "https://www.ehealth.fgov.be/standards/fhir/core/ValueSet/be-civilstate"
    }
  }],
  "url" : "https://www.ehealth.fgov.be/standards/fhir/terminology/ValueSet/be-civilstate",
  "version" : "1.0.0",
  "name" : "BeCivilstate",
  "title" : "BeCivilState",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-20T07:58:55+00:00",
  "publisher" : "eHealth Platform",
  "contact" : [{
    "name" : "eHealth Platform",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ehealth.fgov.be/standards/fhir"
    },
    {
      "system" : "email",
      "value" : "support@be-ehealth-standards.atlassian.net"
    }]
  },
  {
    "name" : "Message Structure eHealth",
    "telecom" : [{
      "system" : "email",
      "value" : "support@be-ehealth-standards.atlassian.net",
      "use" : "work"
    }]
  }],
  "description" : "Codes supported by eHealth Platform differentiating types of civil state. This valueset supports the Belgian federal FHIR profiling effort. Whenever possible add a code from http://terminology.hl7.org/CodeSystem/v3-MaritalStatus for international interoperability but also use https://www.ehealth.fgov.be/standards/fhir/core/CodeSystem/CD-CIVILSTATE for the Belgian specific code.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BE",
      "display" : "Belgium"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-MaritalStatus",
      "concept" : [{
        "code" : "A",
        "designation" : [{
          "language" : "en",
          "value" : "Annuled"
        },
        {
          "language" : "nl-BE",
          "value" : "Nietigverklaring van huwelijk"
        },
        {
          "language" : "fr-BE",
          "value" : "Annulation de marriage"
        }]
      },
      {
        "code" : "D",
        "designation" : [{
          "language" : "en",
          "value" : "Divorced"
        },
        {
          "language" : "nl-BE",
          "value" : "Echtgescheiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Divorced"
        }]
      },
      {
        "code" : "M",
        "designation" : [{
          "language" : "en",
          "value" : "Married"
        },
        {
          "language" : "nl-BE",
          "value" : "Gehuwd"
        },
        {
          "language" : "fr-BE",
          "value" : "Marié"
        }]
      },
      {
        "code" : "U",
        "designation" : [{
          "language" : "en",
          "value" : "Unmarried"
        },
        {
          "language" : "nl-BE",
          "value" : "Ongehuwd"
        },
        {
          "language" : "fr-BE",
          "value" : "Célibataire"
        }]
      },
      {
        "code" : "W",
        "designation" : [{
          "language" : "en",
          "value" : "Widowed"
        },
        {
          "language" : "nl-BE",
          "value" : "Weduwnaar/weduwe"
        },
        {
          "language" : "fr-BE",
          "value" : "Veuf/veuve"
        }]
      }]
    },
    {
      "system" : "https://www.ehealth.fgov.be/standards/fhir/terminology/CodeSystem/cd-civilstate",
      "concept" : [{
        "code" : "10",
        "designation" : [{
          "language" : "en",
          "value" : "Unmarried"
        },
        {
          "language" : "nl-BE",
          "value" : "Ongehuwd"
        },
        {
          "language" : "fr-BE",
          "value" : "Célibataire"
        }]
      },
      {
        "code" : "26",
        "designation" : [{
          "language" : "en",
          "value" : "Putative marriage"
        },
        {
          "language" : "nl-BE",
          "value" : "Putatief huwelijk"
        },
        {
          "language" : "fr-BE",
          "value" : "Mariage putatif"
        }]
      },
      {
        "code" : "40",
        "designation" : [{
          "language" : "en",
          "value" : "Divorced"
        },
        {
          "language" : "nl-BE",
          "value" : "Echtgescheiden"
        },
        {
          "language" : "fr-BE",
          "value" : "Divorced"
        }]
      },
      {
        "code" : "41",
        "designation" : [{
          "language" : "en",
          "value" : "Divorced since 1/10/1994"
        },
        {
          "language" : "nl-BE",
          "value" : "Echtgescheiden vanaf 1/10/1994"
        },
        {
          "language" : "fr-BE",
          "value" : "Divorcé à partir du 1/10/1994"
        }]
      },
      {
        "code" : "50",
        "designation" : [{
          "language" : "en",
          "value" : "Legal separation"
        },
        {
          "language" : "nl-BE",
          "value" : "Gescheiden van tafel en bed"
        },
        {
          "language" : "fr-BE",
          "value" : "Séparé de corps et de biens"
        }]
      },
      {
        "code" : "51",
        "designation" : [{
          "language" : "en",
          "value" : "Legal separation since 1/10/1994"
        },
        {
          "language" : "nl-BE",
          "value" : "Gescheiden van tafel en bed sinds 1/10/1994"
        },
        {
          "language" : "fr-BE",
          "value" : "Séparé de corps et de biens à partir du 1/10/1994"
        }]
      },
      {
        "code" : "60",
        "designation" : [{
          "language" : "en",
          "value" : "Repudiation"
        },
        {
          "language" : "nl-BE",
          "value" : "Verstoting"
        },
        {
          "language" : "fr-BE",
          "value" : "Répudiation"
        }]
      },
      {
        "code" : "80",
        "designation" : [{
          "language" : "en",
          "value" : "Partnership"
        },
        {
          "language" : "nl-BE",
          "value" : "Partnerschap"
        },
        {
          "language" : "fr-BE",
          "value" : "Partenariat"
        }]
      },
      {
        "code" : "81",
        "designation" : [{
          "language" : "en",
          "value" : "End of partnership"
        },
        {
          "language" : "nl-BE",
          "value" : "Partnerschap beeindigd"
        },
        {
          "language" : "fr-BE",
          "value" : "Fin de partenariat"
        }]
      }]
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-NullFlavor",
      "concept" : [{
        "code" : "UNK",
        "designation" : [{
          "language" : "en",
          "value" : "Unknown"
        },
        {
          "language" : "nl-BE",
          "value" : "Onbepaald"
        },
        {
          "language" : "fr-BE",
          "value" : "Indéterminé"
        }]
      }]
    }]
  }
}

```
