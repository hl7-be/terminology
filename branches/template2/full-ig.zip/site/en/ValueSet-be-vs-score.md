# Score Value Set - HL7 Belgium terminology Implementation Guide (IG) v1.0.0

## ValueSet: Score Value Set 

 
Codes as defined by the NIHDI. Dutch translations are expected for a next release. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "be-vs-score",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/replaces",
    "valueCanonical" : "https://www.ehealth.fgov.be/standards/fhir/core-clinical/ValueSet/be-vs-score"
  }],
  "url" : "https://www.ehealth.fgov.be/standards/fhir/terminology/ValueSet/be-vs-score",
  "version" : "1.0.0",
  "name" : "BeVSScore",
  "title" : "Score Value Set",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-27T09:03:57+00:00",
  "description" : "Codes as defined by the NIHDI. Dutch translations are expected for a next release.",
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "763117005",
        "display" : "FINDRISC (Finnish Diabetes Risk Score) score"
      },
      {
        "code" : "446661009",
        "display" : "Visual analog scale score (observable entity)"
      },
      {
        "code" : "273531005",
        "display" : "Index of Independence in Activities of Daily Living"
      },
      {
        "code" : "447316007",
        "display" : "Mini-mental state examination score (observable entity)"
      },
      {
        "code" : "444297006",
        "display" : "Malnutrition universal screening tool score (observable entity)"
      },
      {
        "code" : "443133008",
        "display" : "Norton pressure sore risk score (observable entity)"
      },
      {
        "code" : "7121000122100",
        "display" : "Pain Assessment in Advanced Dementia Scale"
      },
      {
        "code" : "273849003",
        "display" : "Subjective Global Assessment"
      },
      {
        "code" : "450738001",
        "display" : "Thirty second chair stand test score (observable entity)"
      },
      {
        "code" : "444680009",
        "display" : "Timed up and go mobility test score (observable entity)"
      },
      {
        "code" : "278897004",
        "display" : "Waterlow pressure sore risk score"
      },
      {
        "code" : "273364009",
        "display" : "Crohn's disease activity index"
      },
      {
        "code" : "443318007",
        "display" : "Tinetti balance and gait scale"
      },
      {
        "code" : "719124004",
        "display" : "Arthritis Impact Measurement Scales 2 score (observable entity)"
      }]
    },
    {
      "system" : "https://www.ehealth.fgov.be/standards/fhir/terminology/CodeSystem/be-cs-score"
    }]
  }
}

```
