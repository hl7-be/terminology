# Medication origin Type - HL7 Belgium terminology Implementation Guide (IG) v1.0.0

## CodeSystem: Medication origin Type 

 
Medication origin type 

This Code system is referenced in the definition of the following value sets:

* [BeMedicationLineOriginTypeVS](ValueSet-BeMedicationLineOriginTypeVS.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BeMedicationLineOriginType",
  "url" : "https://www.ehealth.fgov.be/standards/fhir/medication/CodeSystem/BeMedicationLineOriginType",
  "version" : "1.1.0",
  "name" : "BeMedicationLineOriginType",
  "title" : "Medication origin Type",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-10-10T13:28:44+02:00",
  "publisher" : "eHealth Platform",
  "contact" : [{
    "name" : "eHealth Platform",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ehealth.fgov.be/standards/fhir"
    },
    {
      "system" : "email",
      "value" : "support@be-ehealth-standards.atlassian.net"
    }]
  },
  {
    "name" : "Message Structure eHealth",
    "telecom" : [{
      "system" : "email",
      "value" : "support@be-ehealth-standards.atlassian.net",
      "use" : "work"
    }]
  }],
  "description" : "Medication origin type",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BE",
      "display" : "Belgium"
    }]
  }],
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 6,
  "concept" : [{
    "code" : "ambulatory-request",
    "display" : "Ambulatory prescription"
  },
  {
    "code" : "hospital-request",
    "display" : "Hospital prescription"
  },
  {
    "code" : "self-medication",
    "display" : "Upon patient demand - Self-medication"
  },
  {
    "code" : "with-request",
    "display" : "Medication not sold in Belgium, with prescription"
  },
  {
    "code" : "without-request",
    "display" : "Medication not sold in Belgium, without prescription"
  },
  {
    "code" : "pharmacist-advice",
    "display" : "Upon pharmacist advice"
  }]
}

```
