# BeCSCareLocation - HL7 Belgium terminology Implementation Guide (IG) v1.0.0

## CodeSystem: BeCSCareLocation 

 
Care Location Code System 

This Code system is referenced in the definition of the following value sets:

* [BeVSCareLocation](ValueSet-be-vs-care-location.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "be-cs-care-location",
  "url" : "https://www.ehealth.fgov.be/standards/fhir/core/CodeSystem/be-cs-care-location",
  "version" : "2.1.2",
  "name" : "BeCSCareLocation",
  "title" : "BeCSCareLocation",
  "status" : "active",
  "experimental" : false,
  "date" : "2021-01-10T10:59:49+00:00",
  "publisher" : "eHealth Platform",
  "contact" : [{
    "name" : "eHealth Platform",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ehealth.fgov.be/standards/fhir"
    },
    {
      "system" : "email",
      "value" : "support@be-ehealth-standards.atlassian.net"
    }]
  },
  {
    "name" : "Message Structure eHealth",
    "telecom" : [{
      "system" : "email",
      "value" : "support@be-ehealth-standards.atlassian.net",
      "use" : "work"
    }]
  }],
  "description" : "Care Location Code System",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BE",
      "display" : "Belgium"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 23,
  "concept" : [{
    "code" : "hospital",
    "display" : "Hospital",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "A l’hôpital"
    },
    {
      "language" : "nl-BE",
      "value" : "Ziekenhuis"
    }]
  },
  {
    "code" : "patient-home",
    "display" : "Patient home",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "A domicile"
    },
    {
      "language" : "nl-BE",
      "value" : "Thuis"
    }]
  },
  {
    "code" : "nursing-home",
    "display" : "Nursing home",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "En maison de repos"
    },
    {
      "language" : "nl-BE",
      "value" : "Rusthuis"
    }]
  },
  {
    "code" : "recovery-home",
    "display" : "Recovery home",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "En maison de revalidation"
    },
    {
      "language" : "nl-BE",
      "value" : "In huis van revalidatie"
    }]
  },
  {
    "code" : "workplace",
    "display" : "Workplace",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "Au cabinet"
    },
    {
      "language" : "nl-BE",
      "value" : "In het kantoor"
    }]
  },
  {
    "code" : "medical-center",
    "display" : "Medical center",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "En maison médicale"
    },
    {
      "language" : "nl-BE",
      "value" : "Medisch huis"
    }]
  },
  {
    "code" : "clinic",
    "display" : "Clinic",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "A la clinique"
    },
    {
      "language" : "nl-BE",
      "value" : "Kliniek"
    }]
  },
  {
    "code" : "pediatric-ic",
    "display" : "Pediatric ic",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "En unité de soins intensive pédiatrique"
    },
    {
      "language" : "nl-BE",
      "value" : "Pediatrische intensive care"
    }]
  },
  {
    "code" : "neonatal-ic",
    "display" : "Neonatal ic",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "En unité de soins intensive pédiatrique néonatal"
    },
    {
      "language" : "nl-BE",
      "value" : "Neonatale pediatrische intensive care"
    }]
  },
  {
    "code" : "prenatal-consult",
    "display" : "Prenatal consult",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "Consultation prénatale"
    },
    {
      "language" : "nl-BE",
      "value" : "prenataal consult"
    }]
  },
  {
    "code" : "m-accueil",
    "display" : "m-accueil",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "Milieu d’accueil"
    },
    {
      "language" : "nl-BE",
      "value" : "kinderopvang"
    }]
  },
  {
    "code" : "child-consult",
    "display" : "Child consult",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "Consultation pour enfant"
    },
    {
      "language" : "nl-BE",
      "value" : "kind consult"
    }]
  },
  {
    "code" : "one",
    "display" : "ONE",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "ONE"
    },
    {
      "language" : "nl-BE",
      "value" : "ONE"
    }]
  },
  {
    "code" : "kind-gezin",
    "display" : "Kind en gezin",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "Kind&Gezin"
    },
    {
      "language" : "nl-BE",
      "value" : "Kind&Gezin"
    }]
  },
  {
    "code" : "ambulance",
    "display" : "Ambulance",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "Ambulance"
    },
    {
      "language" : "nl-BE",
      "value" : "Ambulance"
    }]
  },
  {
    "code" : "school",
    "display" : "School",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "A l’école"
    },
    {
      "language" : "nl-BE",
      "value" : "School"
    }]
  },
  {
    "code" : "school-health-serv",
    "display" : "School health services",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "services de santé scolaire"
    },
    {
      "language" : "nl-BE",
      "value" : "gezondheidsdiensten op school"
    }]
  },
  {
    "code" : "pharmacy",
    "display" : "Pharmacy",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "Pharmacie"
    },
    {
      "language" : "nl-BE",
      "value" : "Apotheek"
    }]
  },
  {
    "code" : "med-monde",
    "display" : "Med monde",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "Médecin du monde"
    },
    {
      "language" : "nl-BE",
      "value" : "dokters van de wereld"
    }]
  },
  {
    "code" : "ngo",
    "display" : "Non-Governmental Organization",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "ONG"
    },
    {
      "language" : "nl-BE",
      "value" : "NGO"
    }]
  },
  {
    "code" : "family-planning",
    "display" : "Family planning",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "Centre planning familial"
    },
    {
      "language" : "nl-BE",
      "value" : "Centrum gezinsplanning"
    }]
  },
  {
    "code" : "abroad",
    "display" : "Abroad",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "A l’étranger"
    },
    {
      "language" : "nl-BE",
      "value" : "Buitenland"
    }]
  },
  {
    "code" : "other",
    "display" : "other",
    "designation" : [{
      "language" : "fr-BE",
      "value" : "Autre"
    },
    {
      "language" : "nl-BE",
      "value" : "Andere"
    }]
  }]
}

```
